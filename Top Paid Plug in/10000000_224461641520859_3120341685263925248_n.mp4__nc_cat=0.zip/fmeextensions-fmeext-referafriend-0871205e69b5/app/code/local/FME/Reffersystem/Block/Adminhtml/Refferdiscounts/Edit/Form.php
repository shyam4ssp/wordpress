<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Block_Adminhtml_Refferdiscounts_Edit_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $Form = new Varien_Data_Form(array(
            'id' => 'edit_form',
            'action' => $this->getUrl('*/*/save', array('id' => $this->getRequest()->getParam('id'))),
            'method' => 'post',
        ));
        $Form->setUseContainer(true);
        $this->setForm($Form);

        $fieldset = $Form->addFieldset('form', array(
            'legend'      => Mage::helper('reffersystem')->__('Discount Information'),
            'class'       => 'fieldset-wide',
            )
        );

        $fieldset->addField('discount_amount', 'text', array(
            'label'     => Mage::helper('reffersystem')->__('Discount Amount'),
            'class'     => 'required-entry',
            'required'  => true,
            'name'      => 'discount_amount',
        ));

        $fieldset->addField('comments', 'text', array(
            'label'     => Mage::helper('reffersystem')->__('Comments'),
            'name'      => 'comments',
        ));

        $fieldset->addField('website_id','select',array(
          'name'      => 'website_id',
          'label'     => Mage::helper('reffersystem')->__('Website'),
          'title'     => Mage::helper('reffersystem')->__('Website'),
          'required'  => true,
          'values'    => Mage::getSingleton('adminhtml/system_store')->getWebsiteValuesForForm(false, false)
        ));
        if(Mage::registry('refferdiscounts_data'))
        {
            $fieldset->addField('customer_id', 'hidden', array(
            'name'      => 'customer_id',
            'value'     =>  Mage::registry('refferdiscounts_data')->getCustomerId(),
            ));

            $fieldset->addField('customer_email', 'hidden', array(
            'name'      => 'customer_email',
            'value'     =>  Mage::registry('refferdiscounts_data')->getCustomerEmail(),
            ));

        }

         if(!$this->getRequest()->getParam('id'))
        
        {
          $fieldset2 = $Form->addFieldset('form2', array(
              'legend'      => Mage::helper('reffersystem')->__('Customer'),
              'class'       => 'fieldset-wide',
              )
          );
       
          $fieldset2->addType('customergrid', 'FME_Reffersystem_Block_Adminhtml_Refferdiscounts_Edit_Render_Customergrid');
          
          $fieldset2->addField('customers', 'customergrid', array(
            
             'name' => 'customers'
            ));
        }
        //echo $this->getLayout()->createBlock('reffersystem/adminhtml_customer_grid');
        if ( Mage::getSingleton('adminhtml/session')->getRefferdiscountsData())
        {
          $Form->setValues(Mage::getSingleton('adminhtml/session')->getRefferdiscountsData());
          Mage::getSingleton('adminhtml/session')->getRefferdiscountsData(null);
        } elseif ( Mage::registry('refferdiscounts_data')) {
          $Form->setValues(Mage::registry('refferdiscounts_data')->getData());
        }
        return parent::_prepareForm();
  }
 
}