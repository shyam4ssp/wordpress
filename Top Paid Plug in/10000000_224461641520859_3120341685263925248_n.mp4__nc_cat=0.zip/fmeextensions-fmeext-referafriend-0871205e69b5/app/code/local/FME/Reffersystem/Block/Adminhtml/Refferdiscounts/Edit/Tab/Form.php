<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Block_Adminhtml_Refferdiscounts_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form(array(
                                      'id' => 'edit_form',
                                      'action' => $this->getUrl('*/*/save', array('id' => $this->getRequest()->getParam('id'))),
                                      'method' => 'post',
                                      'enctype' => 'multipart/form-data'
                                   )
      );

      $form->setUseContainer(true);
      $this->setForm($form);
      $fieldset = $form->addFieldset('refferdiscounts_form', array('legend'=>Mage::helper('reffersystem')->__('
                  General Information')));

    $fieldset->addField('discount_amount', 'text', array(
          'label'     => Mage::helper('reffersystem')->__('Disount Amount'),
          'class'     => 'required-entry',
          'required'  => true,
          'name'      => 'discount_amount',
      ));
      
       $fieldset->addField('comments', 'text', array(
          'label'     => Mage::helper('reffersystem')->__('Comments'),
       
          'required'  => false,
          'name'      => 'comments',
      ));
      if ( Mage::getSingleton('adminhtml/session')->getRefferdiscountsData())
      {

          $form->setValues(Mage::getSingleton('adminhtml/session')->getRefferdiscountsData());
          Mage::getSingleton('adminhtml/session')->setRefferdiscountsData(null);
      } elseif ( Mage::registry('refferdiscounts_data')) {
        $form->setValues(Mage::registry('refferdiscounts_data')->getData());
      }
      return parent::_prepareForm();
  }
 
}