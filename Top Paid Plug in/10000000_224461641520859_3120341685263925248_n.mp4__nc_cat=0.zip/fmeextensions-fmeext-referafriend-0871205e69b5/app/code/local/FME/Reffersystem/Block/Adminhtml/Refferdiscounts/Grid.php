<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Block_Adminhtml_Refferdiscounts_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
  public function __construct()
  {
      parent::__construct();
      $this->setId('refferdiscountsGrid');
      $this->setDefaultSort('discount_id');
      $this->setDefaultDir('ASC');
      $this->setSaveParametersInSession(true);
  }

  protected function _prepareCollection()
  {
      $collection = Mage::getModel('reffersystem/refferdiscounts')->getCollection();
      $this->setCollection($collection);
      return parent::_prepareCollection();
  }

  protected function _getStore()
  {
        $storeId = (int) $this->getRequest()->getParam('store', 0);
        return Mage::app()->getStore($storeId);
  }

  protected function _prepareColumns()
  {
      $this->addColumn('discount_id', array(
          'header'    => Mage::helper('reffersystem')->__('ID'),
          'align'     =>'right',
          'width'     => '50px',
          'index'     => 'discount_id',
      ));

      $this->addColumn('customer_email', array(
          'header'    => Mage::helper('reffersystem')->__('Email'),
          'align'     =>'left',
          'index'     => 'customer_email',
      ));

      $this->addColumn('discount_amount', array(
          'header'    => Mage::helper('reffersystem')->__('Amount %'),
          'align'     =>'left',
          'index'     => 'discount_amount',
          'type'      => 'number',
      ));

      $this->addColumn('trigger', array(
          'header'    => Mage::helper('reffersystem')->__('Count'),
          'align'     =>'left',
          'index'     => 'trigger',
      ));

      $this->addColumn('comments', array(
          'header'    => Mage::helper('reffersystem')->__('Comments'),
          'align'     =>'left',
          'index'     => 'comments',
      ));

      
      if (!Mage::app()->isSingleStoreMode()) {
        $this->addColumn('website_id', array(
                'header'    => Mage::helper('reffersystem')->__('Website'),
                'align'     => 'center',
                'width'     => '80px',
                'type'      => 'options',
                'options'   => Mage::getSingleton('adminhtml/system_store')->getWebsiteOptionHash(true),
                'index'     => 'website_id',
        ));
      }
	  
        $this->addColumn('action',
            array(
                'header'    =>  Mage::helper('reffersystem')->__('Action'),
                'width'     => '100',
                'type'      => 'action',
                'getter'    => 'getId',
                'actions'   => array(
                    array(
                        'caption'   => Mage::helper('reffersystem')->__('Edit'),
                        'url'       => array('base'=> '*/*/edit'),
                        'field'     => 'id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
                'is_system' => true,
        ));
		
		$this->addExportType('*/*/exportCsv', Mage::helper('reffersystem')->__('CSV'));
		$this->addExportType('*/*/exportXml', Mage::helper('reffersystem')->__('XML'));
	  
      return parent::_prepareColumns();
  }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('discount_id');
        $this->getMassactionBlock()->setFormFieldName('refferdiscounts');

        $this->getMassactionBlock()->addItem('delete', array(
             'label'    => Mage::helper('reffersystem')->__('Delete'),
             'url'      => $this->getUrl('*/*/massDelete'),
             'confirm'  => Mage::helper('reffersystem')->__('Are you sure?')
        ));
        return $this;
    }

  public function getRowUrl($row)
  {
      return $this->getUrl('*/*/edit', array('id' => $row->getId()));
  }

}