<?php

/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Block_Adminhtml_Refferstatistics_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
  public function __construct()
  {
      parent::__construct();
      $this->setId('refferstatisticsGrid');
      $this->setDefaultSort('customer_id');
      $this->setDefaultDir('ASC');
      $this->setSaveParametersInSession(true);
      $this->setUseAjax(true);
  }

  protected function _prepareCollection()
  {
      $collection = Mage::getModel('reffersystem/refferstatistics')->getCollection();
      $this->setCollection($collection);
      return parent::_prepareCollection();
  }

  protected function _getStore()
  {
        $storeId = (int) $this->getRequest()->getParam('store', 0);
        return Mage::app()->getStore($storeId);
  }

  protected function _prepareColumns()
  {
     $this->addColumn('customer_id', array(
            'header'    => Mage::helper('customer')->__('ID'),
            'width'     => '50px',
            'index'     => 'customer_id',
            'type'  => 'number',
        ));

      $this->addColumn('customer_email', array(
          'header'    => Mage::helper('reffersystem')->__('Customer Email'),
          'align'     =>'left',
          'index'     => 'customer_email',
      ));

      $this->addColumn('reg_reffarals', array(
          'header'    => Mage::helper('reffersystem')->__('Number Of Registered Referrals'),
          'align'     =>'left',
          'index'     => 'reg_reffarals',
          'type'  => 'number',
      ));

      $this->addColumn('qty_purchased', array(
          'header'    => Mage::helper('reffersystem')->__('Qty Purchased By Referrals'),
          'align'     =>'left',
          'index'     => 'qty_purchased',
          'type'  => 'number',
      ));

      $this->addColumn('amount_purchased', array(
          'header'    => Mage::helper('reffersystem')->__('Amount Spent By Referrals'),
          'align'     =>'left',
          'index'     => 'amount_purchased',
          'type'  => 'number',
      ));

      $this->addColumn('balance', array(
          'header'    => Mage::helper('reffersystem')->__('Balance Amount Of Customer'),
          'align'     =>'left',
          'index'     => 'balance',
          'type'  => 'number',
      ));

      $this->addColumn('active_discount', array(
          'header'    => Mage::helper('reffersystem')->__('Active Discount % Of Customer'),
          'align'     =>'left',
          'index'     => 'active_discount',
          'type'  => 'number',
      ));


      $this->addColumn('money_spent', array(
          'header'    => Mage::helper('reffersystem')->__('Money Spent By Customer'),
          'align'     =>'left',
          'index'     => 'money_spent',
          'type'  => 'number',
      ));

       $this->addColumn('updated_time', array(
            'header'    => Mage::helper('customer')->__('Updated Time'),
            'type'      => 'datetime',
            'align'     => 'center',
            'index'     => 'updated_time',
            'gmtoffset' => true
        ));
	  
		$this->addExportType('*/*/exportCsv', Mage::helper('reffersystem')->__('CSV'));
		$this->addExportType('*/*/exportXml', Mage::helper('reffersystem')->__('XML'));
	  
      return parent::_prepareColumns();
  }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('trans_id');
        $this->getMassactionBlock()->setFormFieldName('refferstatistics');
        return $this;
    }

    public function getGridUrl()
    {
        return $this->getUrl('*/*/grid', array('_current'=> true));
    }


}