<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

 
class FME_Reffersystem_Block_Adminhtml_Reffersystem extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_reffersystem';
    $this->_blockGroup = 'reffersystem';
    $this->_headerText = Mage::helper('reffersystem')->__('Rule Manager');
    $this->_addButtonLabel = Mage::helper('reffersystem')->__('Add Rule');
    parent::__construct();
  }
}