<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Block_Adminhtml_Reffersystem_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
      $this->setForm($form);
      $fieldset = $form->addFieldset('reffersystem_form', array('legend'=>Mage::helper('reffersystem')->__('
                  General Information')));
     
     if(!Mage::registry('reffersystem_data')->getData('rule_name')){
      $fieldset->addField('rule_name', 'text', array(
          'label'     => Mage::helper('reffersystem')->__('Rule Name'),
          'class'     => 'required-entry',
          'required'  => true,
          'name'      => 'rule_name',
      ));
    }

 if(!Mage::registry('reffersystem_data')->getData('rule_type')){
      $fieldset->addField('rule_type', 'select', array(
          'label'     => Mage::helper('reffersystem')->__('Rule Type'),
          'required'  => false,
          'name'      => 'rule_type',
          'type'      => 'options',
          'options'   => array(
              1 => 'Customer Singup',
              2 => 'No of Itmes purchased',
              3 => 'Discount for referrals purchase amount',
          ),
    ));
    }else{
          $fieldset->addField('rule_type', 'note', array(
          'label'     => Mage::helper('reffersystem')->__('Rule Type'),
          'text'     =>$this->getvalue(Mage::registry('reffersystem_data')->getData('rule_type')),
        ));
    }
   if(!Mage::registry('reffersystem_data')->getData('discount_type')){ 
      $fieldset->addField('discount_type', 'select', array(
          'label'     => Mage::helper('reffersystem')->__('Discount Type'),
          'required'  => false,
          'name'      => 'discount_type',
          'type'      => 'options',
          'options'   => array(
              1 => '% Percent Discount',
              2 => 'Fixed Discount',
          ),
        ));
  }else{
          $fieldset->addField('discount_type', 'note', array(
          'label'     => Mage::helper('reffersystem')->__('Discount Type'),
          'text'     =>$this->setDiscounttype(Mage::registry('reffersystem_data')->getData('discount_type')),
        ));
    }

    $fieldset->addField('discount_amount', 'text', array(
          'label'     => Mage::helper('reffersystem')->__('Disount Amount'),
          'class'     => 'required-entry',
          'required'  => true,
          'name'      => 'discount_amount',
      ));
      
      $dateFormatIso = Mage::app()->getLocale()->getDateTimeFormat(Mage_Core_Model_Locale::FORMAT_TYPE_SHORT);
  if(!Mage::registry('reffersystem_data')->getData('reffersystem_id')){     
      $fieldset->addField('active_from', 'date', array(
        'name'   => 'active_from',
        'style'  => 'width:130px',
        'label'  => Mage::helper('reffersystem')->__('Start Date'),
        'title'  => Mage::helper('reffersystem')->__('Start Date'),
        'image'  => $this->getSkinUrl('images/grid-cal.gif'),
        'format' => Mage::app()->getLocale()->getDateFormat(Mage_Core_Model_Locale::FORMAT_TYPE_MEDIUM)

      ));
  }else{
    $fieldset->addField('active_from', 'note', array(
          'label'     => Mage::helper('reffersystem')->__('Start Date'),
          'text'      =>$this->getTimes(Mage::registry('reffersystem_data')->getData('active_from')),
        ));

  }
       $fieldset->addField('target', 'text', array(
          'label'     => Mage::helper('reffersystem')->__('Target'),
          'class'     => 'required-entry',
          'required'  => true,
          'name'      => 'target',
      ));
    $fieldset->addField('prcoess_rule', 'select', array(
          'label'     => Mage::helper('reffersystem')->__('Stop Further Rules Processing'),
          'class'     => 'required-entry',
          'required'  => false,
          'name'      => 'prcoess_rule',
          'type'      => 'options',
          'options'   => array(
              1 => 'Yes',
              0 => 'No',
          ),
      ));
      $fieldset->addField('priority', 'text', array(
          'label'     => Mage::helper('reffersystem')->__('Priority'),
          'class'     => 'required-entry',
          'required'  => false,
          'name'      => 'priority',
      ));

  $fieldset->addField('store_id','multiselect',array(
            'name'      => 'stores[]',
            'label'     => Mage::helper('reffersystem')->__('Store View'),
            'title'     => Mage::helper('reffersystem')->__('Store View'),
            'required'  => true,
            'values'    => Mage::getSingleton('adminhtml/system_store')->getStoreValuesForForm(false, true)
    ));
      if ( Mage::getSingleton('adminhtml/session')->getReffersystemData())
      {

          $form->setValues(Mage::getSingleton('adminhtml/session')->getReffersystemData());
          Mage::getSingleton('adminhtml/session')->setReffersystemData(null);
      } elseif ( Mage::registry('reffersystem_data')) {
       Mage::registry('reffersystem_data')->setData('rule_target',number_format(Mage::registry('reffersystem_data')->getData('rule_target'), 2, null, ''));
       Mage::registry('reffersystem_data')->setData('bonus',number_format(Mage::registry('reffersystem_data')->getData('bonus'), 2, null, ''));
          $form->setValues(Mage::registry('reffersystem_data')->getData());
      }
      return parent::_prepareForm();
  }
  protected function getvalue($txt)
  {
      if($txt =='1') { return 'Customer Singup';
      }else if($txt =='2'){ return 'No of Itmes purchased';}
      else if($txt =='3'){ return 'Discount for referrals purchase amount';}
  }

  protected function setDiscounttype($txt)
  {
    if($txt =='1') { return '% Percent Discount';
      }else if($txt =='2'){ return 'Fixed Discount';}
  }
  protected function getTimes($time)
  {
    return  date('D-m-Y h:i:s A', strtotime($time));
  }
}