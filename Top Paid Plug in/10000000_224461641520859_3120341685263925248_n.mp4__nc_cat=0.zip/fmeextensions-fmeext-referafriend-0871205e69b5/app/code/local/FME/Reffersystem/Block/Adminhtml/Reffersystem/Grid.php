<?php

/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Block_Adminhtml_Reffersystem_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
  public function __construct()
  {
      parent::__construct();
      $this->setId('reffersystemGrid');
      $this->setDefaultSort('rule_id');
      $this->setDefaultDir('ASC');
      $this->setSaveParametersInSession(true);
  }

  protected function _prepareCollection()
  {
      $collection = Mage::getModel('reffersystem/refferrule')->getCollection();
      $this->setCollection($collection);
      return parent::_prepareCollection();
  }

  protected function _getStore()
  {
        $storeId = (int) $this->getRequest()->getParam('store', 0);
        return Mage::app()->getStore($storeId);
  }

  protected function _prepareColumns()
  {
      $this->addColumn('rule_id', array(
          'header'    => Mage::helper('reffersystem')->__('ID'),
          'align'     =>'right',
          'width'     => '50px',
          'index'     => 'rule_id',
      ));

      $this->addColumn('rule_name', array(
          'header'    => Mage::helper('reffersystem')->__('Name'),
          'align'     =>'left',
          'index'     => 'rule_name',
      ));

      $this->addColumn('rule_type', array(
          'header'    => Mage::helper('reffersystem')->__('Rule Type'),
          'align'     => 'left',
          'width'     => '80px',
          'index'     => 'rule_type',
          'type'      => 'options',
          'options'   => array(
              1 => 'Customer Sign Up',
              2 => 'Discount for number of Items',
              3 =>  'Discount for Purchase Amount',
          ),
      ));

      $this->addColumn('priority', array(
          'header'    => Mage::helper('reffersystem')->__('Priority'),
          'align'     =>'left',
          'index'     => 'priority',
      ));

      $this->addColumn('discount_type', array(
          'header'    => Mage::helper('reffersystem')->__('Discount Type'),
          'align'     => 'left',
          'width'     => '80px',
          'index'     => 'discount_type',
          'type'      => 'options',
          'options'   => array(
              1 => 'Percentage',
              2 => 'Fixed',
          ),
      ));

      $store = $this->_getStore();
      
      $this->addColumn('discount_amount', array(
          'header'    => Mage::helper('reffersystem')->__('Discount Amount'),
          'align'     =>'left',
          'index'     => 'discount_amount',
          'currency_code' => $store->getBaseCurrency()->getCode(),
          'type'  => 'currency',
      ));

      $this->addColumn('active_from', array(
          'header'    => Mage::helper('reffersystem')->__('Activation Date'),
          'align'     =>'left',
          'index'     => 'active_from',
          'format' => Mage::app()->getLocale()->getDateFormat(Mage_Core_Model_Locale::FORMAT_TYPE_LONG),
          'type' => 'datetime',
          'time' =>   'false',
        ));

       $this->addColumn('target', array(
          'header'    => Mage::helper('reffersystem')->__('Target'),
          'align'     =>'left',
          'index'     => 'target',
      ));
	  
        $this->addColumn('action',
            array(
                'header'    =>  Mage::helper('reffersystem')->__('Action'),
                'width'     => '100',
                'type'      => 'action',
                'getter'    => 'getId',
                'actions'   => array(
                    array(
                        'caption'   => Mage::helper('reffersystem')->__('Edit'),
                        'url'       => array('base'=> '*/*/edit'),
                        'field'     => 'id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
                'is_system' => true,
        ));
		
		$this->addExportType('*/*/exportCsv', Mage::helper('reffersystem')->__('CSV'));
		$this->addExportType('*/*/exportXml', Mage::helper('reffersystem')->__('XML'));
	  
      return parent::_prepareColumns();
  }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('rule_id');
        $this->getMassactionBlock()->setFormFieldName('reffersystem');

        $this->getMassactionBlock()->addItem('delete', array(
             'label'    => Mage::helper('reffersystem')->__('Delete'),
             'url'      => $this->getUrl('*/*/massDelete'),
             'confirm'  => Mage::helper('reffersystem')->__('Are you sure?')
        ));

        $statuses = Mage::getSingleton('reffersystem/status')->getOptionArray();

        array_unshift($statuses, array('label'=>'', 'value'=>''));
        $this->getMassactionBlock()->addItem('status', array(
             'label'=> Mage::helper('reffersystem')->__('Change status'),
             'url'  => $this->getUrl('*/*/massStatus', array('_current'=>true)),
             'additional' => array(
                    'visibility' => array(
                         'name' => 'status',
                         'type' => 'select',
                         'class' => 'required-entry',
                         'label' => Mage::helper('reffersystem')->__('Status'),
                         'values' => $statuses
                     )
             )
        ));
        return $this;
    }

  public function getRowUrl($row)
  {
      return $this->getUrl('*/*/edit', array('id' => $row->getId()));
  }

}