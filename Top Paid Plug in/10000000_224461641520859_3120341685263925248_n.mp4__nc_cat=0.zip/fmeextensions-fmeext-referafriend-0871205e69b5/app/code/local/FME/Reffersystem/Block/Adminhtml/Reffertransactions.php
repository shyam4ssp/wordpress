<?php

/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

 
class FME_Reffersystem_Block_Adminhtml_Reffertransactions extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_reffertransactions';
    $this->_blockGroup = 'reffersystem';
    $this->_headerText = Mage::helper('reffersystem')->__('Transction Manager');
    $this->_addButtonLabel = Mage::helper('reffersystem')->__('Add Transction');
    parent::__construct();
  }
}