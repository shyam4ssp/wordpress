<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Block_Adminhtml_Reffertransactions_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'reffersystem';
        $this->_controller = 'adminhtml_reffertransactions';
        
        $this->_updateButton('save', 'label', Mage::helper('reffersystem')->__('Save Transcations'));
        $this->_updateButton('delete', 'label', Mage::helper('reffersystem')->__('Delete Transcations'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('reffersystem_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'reffersystem_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'reffersystem_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('reffertransactions_data') && Mage::registry('reffertransactions_data')->getId()) {
            return Mage::helper('reffersystem')->__("Edit Transcations for' %s '", $this->htmlEscape(Mage::registry('reffertransactions_data')->getCustomerEmail()));
        } else {
            return Mage::helper('reffersystem')->__('Add Transcations');
        }
    }
}