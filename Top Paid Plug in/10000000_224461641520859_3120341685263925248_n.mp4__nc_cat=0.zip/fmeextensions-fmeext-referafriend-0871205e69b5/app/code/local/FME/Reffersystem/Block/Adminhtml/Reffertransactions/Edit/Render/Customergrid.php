<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Block_Adminhtml_Reffertransactions_Edit_Render_Customergrid extends Varien_Data_Form_Element_Abstract
{
 	protected $_element;
 
	public function getElementHtml()
    {
        return Mage::app()->getLayout()->createBlock('reffersystem/adminhtml_customer_grid')->toHtml();
    }
 
}