<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Block_Adminhtml_Reffertransactions_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
  public function __construct()
  {
      parent::__construct();
      $this->setId('reffertransactionsGrid');
      $this->setDefaultSort('trans_id');
      $this->setDefaultDir('ASC');
      $this->setSaveParametersInSession(true);
  }

  protected function _prepareCollection()
  {
      $collection = Mage::getModel('reffersystem/reffertransactions')->getCollection();
      $this->setCollection($collection);
      return parent::_prepareCollection();
  }

  protected function _getStore()
  {
        $storeId = (int) $this->getRequest()->getParam('store', 0);
        return Mage::app()->getStore($storeId);
  }

  protected function _prepareColumns()
  {
      $this->addColumn('trans_id', array(
          'header'    => Mage::helper('reffersystem')->__('ID'),
          'align'     =>'right',
          'width'     => '50px',
          'index'     => 'trans_id',
      ));

      $this->addColumn('customer_email', array(
          'header'    => Mage::helper('reffersystem')->__('Email'),
          'align'     =>'left',
          'index'     => 'customer_email',
      ));

      $this->addColumn('balance', array(
          'header'    => Mage::helper('reffersystem')->__('Active Balance'),
          'align'     =>'left',
          'index'     => 'balance',
      ));

      
      $this->addColumn('comments', array(
          'header'    => Mage::helper('reffersystem')->__('Comments'),
          'align'     =>'left',
          'index'     => 'comments',
      ));

      $store = $this->_getStore();
      
      if (!Mage::app()->isSingleStoreMode()) {
        $this->addColumn('website_id', array(
                'header'    => Mage::helper('reffersystem')->__('Website'),
                'align'     => 'center',
                'width'     => '80px',
                'type'      => 'options',
                'options'   => Mage::getSingleton('adminhtml/system_store')->getWebsiteOptionHash(true),
                'index'     => 'website_id',
        ));
      }

      $this->addColumn('created_time', array(
            'header'    => Mage::helper('customer')->__('Created Time'),
            'type'      => 'datetime',
            'align'     => 'center',
            'index'     => 'created_time',
            'gmtoffset' => true
        ));
		
		$this->addExportType('*/*/exportCsv', Mage::helper('reffersystem')->__('CSV'));
		$this->addExportType('*/*/exportXml', Mage::helper('reffersystem')->__('XML'));
	  
      return parent::_prepareColumns();
  }

    protected function _prepareMassaction()
    {
        
        return $this;
    }

}