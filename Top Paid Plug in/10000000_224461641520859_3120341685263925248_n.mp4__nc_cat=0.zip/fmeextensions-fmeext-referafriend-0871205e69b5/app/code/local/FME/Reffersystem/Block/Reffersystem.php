<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Block_Reffersystem extends Mage_Core_Block_Template
{
	public function __construct()
 {
        parent::__construct();
        $customer = Mage::getSingleton('customer/session')->getCustomer();
        $id = $customer->getId();
        $storeId = Mage::app()->getStore()->getStoreId();
        $collection = Mage::getModel('reffersystem/refferemails')->getCollection()->addFieldToFilter('reffer_customer_id',$id)->addFieldToFilter('store_id', $storeId);
        $this->setCollection($collection);
    }
     protected function _prepareLayout()
     {
        parent::_prepareLayout();
        $this->getLayout()->getBlock('head')
            ->setTitle(Mage::helper('reffersystem')->__('Reffer Friend'));
        $pager = $this->getLayout()->createBlock('page/html_pager', 'reffersystem.pager');
        $pager->setAvailableLimit(array(5=>5,10=>10,20=>20,50=>50));
        $pager->setCollection($this->getCollection());
        $this->setChild('pager', $pager);
        $this->getCollection()->load();
        return $this;
    }
 
    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }

     public function getReffersystem()     
     { 
        if (!$this->hasData('reffersystem')) {
            $this->setData('reffersystem', Mage::registry('reffersystem'));
        }
        return $this->getData('reffersystem');
        
    }

}