<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Helper_Data extends Mage_Core_Helper_Abstract
{
	const XML_PATH_REFER_ENABLE				=	'reffersystem/setting/status';
	const XML_CALCULATE_PURCHASE_AMOUNT		=	'reffersystem/setting/purchaeamount';
	const XML_MAXIMUM_DISCOUNT				=	'reffersystem/setting/maximumdiscount';
	const XML_APPLY_CART_CONDITION			=	'reffersystem/setting/discountprice';
	const XML_MAXIMUM_BALANCE_CUSTOMER		=	'reffersystem/setting/maximumbalance';
	const XML_REFERRAL_APPLY_DISCOUNT		=	'reffersystem/referralsettings/referraldiscount';
	const XML_REFERRAL_DISCOUNT_TYPE		=	'reffersystem/referralsettings/bounstype';
	const XML_REFERRAL_DISCOUNT_AMOUNT		=	'reffersystem/referralsettings/bounsamount';
	const XML_EMAIL_ENABLE					=	'reffersystem/emailsetting/enableemail';
	const XML_EMAIL_SENDER					=	'reffersystem/emailsetting/sender_email_identity';
	const XML_EMAIL_TEMPLATE				=	'reffersystem/emailsetting/referemailtemplate';

	public function getReferEnable()
	{
		return Mage::getStoreConfig(self::XML_PATH_REFER_ENABLE);
	}

	public function getPurchaseAmountCalculations()
	{
		return Mage::getStoreConfig(self::XML_CALCULATE_PURCHASE_AMOUNT);
	}

	public function getMaximumDiscount()
	{
		return Mage::getStoreConfig(self::XML_MAXIMUM_DISCOUNT);
	}

	public function getCartCondition()
	{
		return Mage::getStoreConfig(self::XML_APPLY_CART_CONDITION);
	}

	public function getCustomerMaxBalance()
	{
		return Mage::getStoreConfig(self::XML_MAXIMUM_BALANCE_CUSTOMER);
	}

	public function getReferralEnable()
	{
		return Mage::getStoreConfig(self::XML_REFERRAL_APPLY_DISCOUNT);
	}

	public function getReferralDiscountType()
	{
		return Mage::getStoreConfig(self::XML_REFERRAL_DISCOUNT_TYPE);
	}

	public function getReferralDiscountAmount()
	{
		return Mage::getStoreConfig(self::XML_REFERRAL_DISCOUNT_AMOUNT);
	}

	public function getEmailEnable()
	{
		return Mage::getStoreConfig(self::XML_EMAIL_ENABLE);
	}

	public function getSenderEmail()
	{
		$sender =  Mage::getStoreConfig(self::XML_EMAIL_SENDER);
		if($sender=='general')
		{
			return Mage::getStoreConfig('trans_email/ident_general/email');
		}
		elseif($sender='sales')
		{
			return Mage::getStoreConfig('trans_email/ident_sales/email');
		}
		elseif($sender=='support')
		{
			return Mage::getStoreConfig('trans_email/ident_support/email');
		}
		elseif($sender=='custom1')
		{
			return Mage::getStoreConfig('trans_email/ident_custom1/email');
		}
		elseif ($sender=='custom2') {
			return Mage::getStoreConfig('trans_email/ident_custom2/email');
		}

	}

	public function getSenderName()
	{
		$sender =  Mage::getStoreConfig(self::XML_EMAIL_SENDER);
		if($sender=='general')
		{
			return Mage::getStoreConfig('trans_email/ident_general/name');
		}
		elseif($sender='sales')
		{
			return Mage::getStoreConfig('trans_email/ident_sales/name');
		}
		elseif($sender=='support')
		{
			return Mage::getStoreConfig('trans_email/ident_support/name');
		}
		elseif($sender=='custom1')
		{
			return Mage::getStoreConfig('trans_email/ident_custom1/name');
		}
		elseif ($sender=='custom2') {
			return Mage::getStoreConfig('trans_email/ident_custom2/name');
		}

	}

	public function getEmailTemplate()
	{
		return Mage::getStoreConfig(self::XML_EMAIL_TEMPLATE);
	}

	public function getReferralstatus($value)
	{	
		if($value==1)
		{
			return "Yes";
		}
		else
		{ 
			return "No";
		}
	}

	public function encryptBoradCastLink($string)
	{
		$output = false;
		$encrypt_method = "AES-256-CBC";
    	$secret_key = '!@#$%^&*TYvd';
    	$secret_iv = '24587360';
		// Hashes For Url
    	$key = hash('sha256', $secret_key);
    	// iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    	$iv = substr(hash('sha256', $secret_iv), 0, 16);
	    $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
	    $output = base64_encode($output);
	    return $output;
	}

	public function decryptBoradCastLink($string)
	{
		$output = false;
		$encrypt_method = "AES-256-CBC";
    	$secret_key = '!@#$%^&*TYvd';
    	$secret_iv = '24587360';
		// Hashes For Url
    	$key = hash('sha256', $secret_key);
    	// iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    	$iv = substr(hash('sha256', $secret_iv), 0, 16);
	    $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
	    return $output;

	}
}