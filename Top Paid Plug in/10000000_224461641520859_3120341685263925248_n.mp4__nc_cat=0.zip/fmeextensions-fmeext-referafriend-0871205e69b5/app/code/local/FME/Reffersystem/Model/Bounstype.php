<?php

/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Model_Bounstype extends Mage_Core_Model_Abstract
{
  
    const FIXED	= 1;
    const PERCENTAGE	= 2;

    static public function toOptionArray()
    {
        return array(
            self::FIXED    => Mage::helper('reffersystem')->__('Fixed'),
            self::PERCENTAGE   => Mage::helper('reffersystem')->__('Percentage %')
        );
    }
    
}