<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Model_Mysql4_Reffercheckouts extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the discount_id refers to the key field in your database table.
        $this->_init('reffersystem/reffercheckouts', 'chk_id');
    }

    public function load(Mage_Core_Model_Abstract $object, $value, $field=null)
    {
      
        if ($field!=NULL) {
            $field = 'order_id';
        }

        return parent::load($object, $value, $field);
    }
	
}