<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Model_Mysql4_Refferdiscounts extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the discount_id refers to the key field in your database table.
        $this->_init('reffersystem/refferdiscounts', 'discount_id');
    }

    public function insetReferDiscount($discount,$customer_id)
    {
    	$model = Mage::getModel('reffersystem/refferdiscounts');
		$refer_customer = Mage::getModel('customer/customer')->load($customer_id);
		$data['customer_id'] = $customer_id;
		$data['customer_email'] = $refer_customer->getEmail();
		$trigger = 1;
    	$discounts = $this->_getReadAdapter()->select()->from(array('main_table'=>$this->getMainTable(),'discount_id'))
            ->where('main_table.customer_id = ?', array($customer_id))
            ->limit(1);
        $discount_id = $this->_getReadAdapter()->fetchOne($discounts);
        /*If Customer Data exists in Discount Table*/
         if(!empty($discount_id))
         {
         	$model->load($discount_id);
         	$data['discount_amount'] = $model->getDiscountAmount() + $discount;
         	$data['trigger'] = $model->getTrigger() + $trigger;
         	$model->addData($data);
         	$model->save();

         }
        /*Else*/
        else
        {
        	$data['discount_amount'] =  $discount;
         	$data['trigger'] = $trigger;
         	$data['website_id'] = $refer_customer->getWebsiteId();
         	$data['created_time'] = now();
         	$model->setData($data);
         	$model->save();
        }


    }

    public function removeReferDiscounts($discount,$customer_id)
    {
        $model = Mage::getModel('reffersystem/refferdiscounts');
        $refer_customer = Mage::getModel('customer/customer')->load($customer_id);
        $data['customer_id'] = $customer_id;
        $data['customer_email'] = $refer_customer->getEmail();
        $trigger = 1;
        $discounts = $this->_getReadAdapter()->select()->from(array('main_table'=>$this->getMainTable(),'discount_id'))
            ->where('main_table.customer_id = ?', array($customer_id))
            ->limit(1);
        $discount_id = $this->_getReadAdapter()->fetchOne($discounts);
        /*If Customer Data exists in Discount Table*/
         if(!empty($discount_id))
         {
            $model->load($discount_id);
            $data['discount_amount'] = $model->getDiscountAmount() - $discount;
            $data['trigger'] = $model->getTrigger() - $trigger;
            $model->addData($data);
            $model->save();

         }
    }

	
}