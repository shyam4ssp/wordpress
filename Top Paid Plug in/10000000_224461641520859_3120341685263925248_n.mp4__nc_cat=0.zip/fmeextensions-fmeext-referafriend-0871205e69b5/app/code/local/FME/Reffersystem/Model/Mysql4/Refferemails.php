<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Model_Mysql4_Refferemails extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the discount_id refers to the key field in your database table.
        $this->_init('reffersystem/refferemails', 'refferal_id');
    }

    public function load(Mage_Core_Model_Abstract $object, $value, $field=null)
    {
      
        if (strcmp($value, (int)$value) !== 0) {
            $field = 'email';
        }
        return parent::load($object, $value, $field);
    }
	
}