<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Model_Mysql4_Refferrule extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the reffersystem_id refers to the key field in your database table.
        $this->_init('reffersystem/refferrule', 'rule_id');
    }
	/*After Load Set Stores To Rules Collection*/
	protected function _afterLoad(Mage_Core_Model_Abstract $object)
	{
		$select = $this->_getReadAdapter()->select()
			->from($this->getTable('rulestore'))
			->where('rule_id = ?', $object->getId());
		if ($data = $this->_getReadAdapter()->fetchAll($select)) 
		{
			$storesArray = array();
			foreach ($data as $row) {
				$storesArray[] = $row['store_id'];
			}
			$object->setData('store_id', $storesArray);
			Mage::getSingleton('core/session')->setMyValue($storesArray);
		}
		return parent::_afterLoad($object);
	}

	/*Save Stores Value To Rules*/
    protected function _afterSave(Mage_Core_Model_Abstract $object)
    {		
		$condition = $this->_getWriteAdapter()->quoteInto('rule_id = ?', $object->getId());
		$this->_getWriteAdapter()->delete($this->getTable('rulestore'), $condition);
		$arr = (array)$object->getData('stores');
		if(in_array('0', $arr))
		{
			$allStores = Mage::app()->getStores();
			foreach ($allStores as $_eachStoreId => $val)
			{
				$_storeId[] = Mage::app()->getStore($_eachStoreId)->getId();
			}
			foreach ($_storeId as $store) 
			{
				$storeArray = array();
				$storeArray['rule_id'] = $object->getId();
				$storeArray['store_id'] = $store;
				$this->_getWriteAdapter()->insert($this->getTable('rulestore'), $storeArray);
			}
			}
			else
			{
				foreach ((array)$object->getData('stores') as $store) 
				{
					$storeArray = array();
					$storeArray['rule_id'] = $object->getId();
					$storeArray['store_id'] = $store;
					$this->_getWriteAdapter()->insert($this->getTable('rulestore'), $storeArray);
				}
			}
		return parent::_afterSave($object);
	}

	public function getSignUpRule($store_id)
 {
       $rules = $this->_getReadAdapter()->select()->from(array('main_table'=>$this->getMainTable()))
                ->join(array('store' => $this->getTable('reffersystem/rulestore')),
                    'main_table.rule_id = store.rule_id',array())
                ->where('main_table.rule_type = ?', 1)
                ->where('main_table.active_from <= CURDATE()')
                ->where('store.store_id = ?',$store_id)
                ->order('main_table.priority ASC')
                ->limit(1);
        $rule = $this->_getReadAdapter()->fetchAll($rules);
        if(empty($rule))
        {
            return false;
        } 
        else
        {
            return  $rule;
        }   
        
    }

    public function getOrderItemRule($store_id)
    {
    	$rules = $this->_getReadAdapter()->select()->from(array('main_table'=>$this->getMainTable()))
            ->join(array('store' => $this->getTable('reffersystem/rulestore')),
                    'main_table.rule_id = store.rule_id',array())
            ->where('main_table.rule_type = ?', 2)
             ->where('main_table.active_from <= CURDATE()')
             ->where('store.store_id = ?',$store_id)
            ->order('main_table.priority ASC')
            ->limit(1);
        $rule = $this->_getReadAdapter()->fetchAll($rules);
        if(empty($rule))
        {
            return false;
        } 
        else
        {
            return  $rule;
        }

    }

    public function getOrderAmountRule($store_id)
    {
    	$rules = $this->_getReadAdapter()->select()->from(array('main_table'=>$this->getMainTable()))
            ->join(array('store' => $this->getTable('reffersystem/rulestore')),
                    'main_table.rule_id = store.rule_id',array())
            ->where('main_table.rule_type = ?', 3)
             ->where('main_table.active_from <= CURDATE()')
             ->where('store.store_id = ?',$store_id)
            ->order('main_table.priority ASC')
            ->limit(1);
        $rule = $this->_getReadAdapter()->fetchAll($rules);
        if(empty($rule))
        {
            return false;
        } 
        else
        {
            return  $rule;
        }

    }
}