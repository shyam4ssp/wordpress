<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Model_Mysql4_Refferstatistics extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the discount_id refers to the key field in your database table.
        $this->_init('reffersystem/refferstatistics', 'customer_id');
        $this->_isPkAutoIncrement = false;
    }
	

	public function insertSatisticsData($checkRules,$customer_id)
	{
		//Check If Customer Already exists
		$model = Mage::getModel('reffersystem/refferstatistics');
		$refer_customer = Mage::getModel('customer/customer')->load($customer_id);
		$data['customer_id'] = $customer_id;
		$data['customer_email'] = $refer_customer->getEmail();
		if($checkRules[0]['discount_type']==2)
		{
			$discount_amount = $checkRules[0]['discount_amount']/100;
		}
		else
		{
			$discount_amount = $checkRules[0]['discount_amount'];
		}
		$customers = $this->_getReadAdapter()->select()->from(array('main_table'=>$this->getMainTable(),'customer_id'))
            ->where('main_table.customer_id = ?', array($customer_id))
            ->limit(1);
         $customer = $this->_getReadAdapter()->fetchOne($customers);
         /*If Customer Data exists*/
         if(!empty($customer))
         {
         	/*Load Refer Data*/
         	$model->load($customer_id);
         	/*Check Rule Target*/
         	$ruleTarget = $checkRules[0]['target'];
         	$referTarget = $model->getRegReffarals() + 1;
         	/*If Target Achived*/
         	if($referTarget==$ruleTarget OR $referTarget > $ruleTarget)
         	{
         		$data['reg_reffarals'] = $referTarget;
         		$active_discount = $model->getActiveDiscount() + $discount_amount;
         		$data['active_discount'] = $active_discount;
         		Mage::getModel('reffersystem/refferdiscounts')->insetReferDiscount($discount_amount,$customer_id);
         		$data['updated_time'] = now(); 
         	}
         	/*else*/
         	else
         	{
         		$data['reg_reffarals'] = $referTarget;
         		$data['updated_time'] = now();
         		
         	}
	         	$model->addData($data);
	         	$model->save();
	         	
         }
         /*If New Reffer*/
         else
         {
         	/*Check Target*/
         	//print_r($checkRules);
         	if($checkRules[0]['target']==0 OR $checkRules[0]['target']==1)
         	{
         		$data['reg_reffarals'] = 1;
         		$data['created_time'] = now();
         		$data['updated_time'] = now();
         		$data['active_discount'] = $discount_amount;
         		Mage::getModel('reffersystem/refferdiscounts')->insetReferDiscount($discount_amount,$customer_id);
         	}
         	else
         	{
         		$data['reg_reffarals'] = 1;
         		$data['created_time'] = now();
         		$data['updated_time'] = now();
         	}
         	$model->setData($data);
         	$model->save();
         }
	}

	public function insertSatisticsDataByOrderRules($checkRules,$customer_id,$order,$chk_model)
	{
		//Check If Customer Already exists
		$model = Mage::getModel('reffersystem/refferstatistics');
		$refer_customer = Mage::getModel('customer/customer')->load($customer_id);
		$data['customer_id'] = $customer_id;
		$data['customer_email'] = $refer_customer->getEmail();
		if($checkRules[0]['discount_type']==2)
		{
			$discount_amount = $checkRules[0]['discount_amount']/100;
		}
		else
		{
			$discount_amount = $checkRules[0]['discount_amount'];
		}
		$customers = $this->_getReadAdapter()->select()->from(array('main_table'=>$this->getMainTable(),'customer_id'))
            ->where('main_table.customer_id = ?', array($customer_id))
            ->limit(1);
         $customer = $this->_getReadAdapter()->fetchOne($customers);
         /*If Customer Data exists*/
         if(!empty($customer))
         {
         	/*Load Refer Data*/
         	$model->load($customer_id);
         	/*Check Rule Target*/
         	$ruleTarget = $checkRules[0]['target'];
         	if($checkRules[0]['rule_type']==2)
         	{
         		$referTarget = $order->getTotalItemCount();
         	}
         	elseif($checkRules[0]['rule_type']==3)
         	{
         		$referTarget = $order->getBaseGrandTotal();
         	}
         	/*If Target Achived*/
         	if($referTarget==$ruleTarget OR $referTarget > $ruleTarget)
         	{
         		$active_discount = $model->getActiveDiscount() + $discount_amount;
         		$data['active_discount'] = $active_discount;
         		Mage::getModel('reffersystem/refferdiscounts')->insetReferDiscount($discount_amount,$customer_id);
         		$data['updated_time'] = now(); 
         		$chk_data['amount'] = $discount_amount;
         		$chk_data['applied'] =1;
         		$chk_model->addData($chk_data)->save();
         	}
         	/*else*/
         	else
         	{
         		$data['updated_time'] = now();
         		
         	}
	         	$model->addData($data);
	         	$model->save();
	         	
         }
         /*If New Reffer*/
         else
         {
         	if($checkRules[0]['rule_type']==2)
         	{
         		$referTarget = $order->getTotalItemCount();
         	}
         	elseif($checkRules[0]['rule_type']==3)
         	{
         		$referTarget = $order->getBaseGrandTotal();
         	}
         	/*If Target Achived*/
         	if($referTarget==$ruleTarget OR $referTarget > $ruleTarget)
         	{
         		$data['created_time'] = now();
         		$data['updated_time'] = now();
         		$data['active_discount'] = $discount_amount;
         		Mage::getModel('reffersystem/refferdiscounts')->insetReferDiscount($discount_amount,$customer_id);
         		$chk_data['amount'] = $discount_amount;
         		$chk_data['applied'] =1;
         		$chk_model->addData($chk_data)->save();
         	}
         	else
         	{
         		$data['reg_reffarals'] = 1;
         		$data['created_time'] = now();
         		$data['updated_time'] = now();
         	}
         	$model->setData($data);
         	$model->save();
         }
	}

   public function adminAddDiscounts($customer_id,$discount)
   {
      $model = Mage::getModel('reffersystem/refferstatistics');
      $customers = $this->_getReadAdapter()->select()->from(array('main_table'=>$this->getMainTable(),'customer_id'))
            ->where('main_table.customer_id = ?', array($customer_id))
            ->limit(1);
      $customer = $this->_getReadAdapter()->fetchOne($customers);
      if(!empty($customer))
      {
            $model->load($customer);
            $data['updated_time'] = now();
            $data['active_discount'] = $discount;
            $model->addData($data);
            $model->save();
      }
      else
      {
         $refer_customer = Mage::getModel('customer/customer')->load($customer_id);
         $data['customer_id'] = $customer_id;
         $data['customer_email'] = $refer_customer->getEmail();
         $data['active_discount'] = $discount;
         $data['created_time'] = now();
         $data['updated_time'] = now();
         $model->setData($data);
         $model->save();

      }
   }

   public function load(Mage_Core_Model_Abstract $object, $value, $field=null)
   {
      
        return parent::load($object, $value, $field);
   }

   public function adminAddBalance($customer_id,$balance)
   {
     $model = Mage::getModel('reffersystem/refferstatistics');
      $customers = $this->_getReadAdapter()->select()->from(array('main_table'=>$this->getMainTable(),'customer_id'))
            ->where('main_table.customer_id = ?', array($customer_id))
            ->limit(1);
      $customer = $this->_getReadAdapter()->fetchOne($customers);
      if(!empty($customer))
      {
            $model->load($customer);
            $data['updated_time'] = now();
            $data['balance'] = $model->getBalance() + $balance;
            $model->addData($data);
            $model->save();
      }
      else
      {
         $refer_customer = Mage::getModel('customer/customer')->load($customer_id);
         $data['customer_id'] = $customer_id;
         $data['customer_email'] = $refer_customer->getEmail();
         $data['balance'] = $balance;
         $data['created_time'] = now();
         $data['updated_time'] = now();
         $model->setData($data);
         $model->save();

      } 
   }


   public function deductBalance($customer_id,$customer_email,$discount_amount,$money)
   {
      $stat_model = Mage::getModel('reffersystem/refferstatistics');
      $customers = $this->_getReadAdapter()->select()->from(array('main_table'=>$this->getMainTable(),'customer_id'))
            ->where('main_table.customer_id = ?', array($customer_id))
            ->limit(1);
      $customer = $this->_getReadAdapter()->fetchOne($customers);
      $refer_customer = Mage::getModel('customer/customer')->load($customer_id);
      if(!empty($customer))
      {
            $stat_model->load($customer);
            $stat_data['updated_time'] = now();
            $stat_data['balance'] = $stat_model->getBalance() + $discount_amount;
            $stat_data['money_spent'] = $stat_model->getMoneySpent() + $money;
            $stat_model->addData($stat_data);
            $stat_model->save();
            $trans_data['customer_id'] = $customer_id;
            $trans_data['customer_email'] = $customer_email;
            $trans_data['balance'] = $discount_amount;
            $trans_data['comments'] = 'Refer spent on order';
            $trans_data['website_id'] = $refer_customer->getWebsiteId();
            $trans_data['created_time'] = now();
            $trnas_model = Mage::getModel('reffersystem/reffertransactions');
            $trnas_model->setData($trans_data);
            $trnas_model->save();
      }

   }

   public function deductDiscount($customer_id,$customer_email,$percent,$money)
   {

      $stat_model = Mage::getModel('reffersystem/refferstatistics');
      $customers = $this->_getReadAdapter()->select()->from(array('main_table'=>$this->getMainTable(),'customer_id'))
            ->where('main_table.customer_id = ?', array($customer_id))
            ->limit(1);
      $customer = $this->_getReadAdapter()->fetchOne($customers);
      $refer_customer = Mage::getModel('customer/customer')->load($customer_id);
      if(!empty($customer))
      {
            $stat_model->load($customer);
            $stat_data['updated_time'] = now();
            $stat_data['active_discount'] = $stat_model->getActiveDiscount() - $percent;
            $stat_data['money_spent'] = $stat_model->getMoneySpent() + $money;
            $stat_model->addData($stat_data);
            $stat_model->save();
            Mage::getModel('reffersystem/refferdiscounts')->removeReferDiscounts($percent,$customer_id);

      }

   }

   public function addBalance($customer_id,$customer_email,$discount_amount,$money)
   {
      $stat_model = Mage::getModel('reffersystem/refferstatistics');
      $customers = $this->_getReadAdapter()->select()->from(array('main_table'=>$this->getMainTable(),'customer_id'))
            ->where('main_table.customer_id = ?', array($customer_id))
            ->limit(1);
      $customer = $this->_getReadAdapter()->fetchOne($customers);
      $refer_customer = Mage::getModel('customer/customer')->load($customer_id);
      if(!empty($customer))
      {
         //print_r($discount_amount); exit();
            $stat_model->load($customer);
            $stat_data['updated_time'] = now();
            $stat_data['balance'] = $stat_model->getBalance() + $discount_amount;
            $stat_data['money_spent'] = $stat_model->getMoneySpent() - $money;
            $stat_model->addData($stat_data);
            $stat_model->save();

            $trans_data['customer_id'] = $customer_id;
            $trans_data['customer_email'] = $customer_email;
            $trans_data['balance'] = +$discount_amount;
            $trans_data['comments'] = 'Order Refunded';
            $trans_data['website_id'] = $refer_customer->getWebsiteId();
            $trans_data['created_time'] = now();
            $trnas_model = Mage::getModel('reffersystem/reffertransactions');
            $trnas_model->setData($trans_data);
            $trnas_model->save();
      }

   }

   public function addDiscount($customer_id,$customer_email,$percent,$money)
   {

      $stat_model = Mage::getModel('reffersystem/refferstatistics');
      $customers = $this->_getReadAdapter()->select()->from(array('main_table'=>$this->getMainTable(),'customer_id'))
            ->where('main_table.customer_id = ?', array($customer_id))
            ->limit(1);
      $customer = $this->_getReadAdapter()->fetchOne($customers);
      $refer_customer = Mage::getModel('customer/customer')->load($customer_id);
      if(!empty($customer))
      {
            $stat_model->load($customer);
            $stat_data['updated_time'] = now();
            $stat_data['active_discount'] = $stat_model->getActiveDiscount() + $percent;
            $stat_data['money_spent'] = $stat_model->getMoneySpent() - $money;
            $stat_model->addData($stat_data);
            $stat_model->save();
            Mage::getModel('reffersystem/refferdiscounts')->insetReferDiscount($percent,$customer_id);

      }

   }
}