<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Model_Observer 
{
 
  
  public function referalRegistration($object)
  {
    $lastUrl = Mage::getSingleton('core/session')->getLastUrl();
   $storeId = Mage::app()->getStore()->getStoreId();
      //If Customer Is Come Through Boradcast Link
     if(Mage::getModel('core/cookie')->get('broadcast_refer_customer'))
     {
        $customer = $object->getCustomer();
        /*Insert Customer Data into Refer Account*/
        $data['email'] = $customer->getEmail();
        $data['message'] = 'Broad Cast Link';
        $data['subject'] = 'Broad Cast Link';
        $data['store_id'] = $customer->getStoreId();
        $data['sign_up'] = 1;
        $data['confirmed'] = 1;
        $data['reffer_customer_id'] = Mage::getModel('core/cookie')->get('broadcast_refer_customer');
        $data['discount_get'] = 0;
        $data['created_time'] = now();
        try{
              $model = Mage::getModel('reffersystem/refferemails');
              $model->setData($data);
              $model->save();
        }
        catch (Exception $e) {
            return;
        }
        
        /*Check For Sign Up Rules*/
        $checkRules = Mage::getModel('reffersystem/refferrule')->getSignUpRule($storeId);
        if($checkRules)
        {
            Mage::getModel('reffersystem/refferstatistics')->insertSatisticsData($checkRules,Mage::getModel('core/cookie')->get('broadcast_refer_customer'));
        }
        //exit();
     }
     elseif(Mage::getModel('core/cookie')->get('email_refer_customer'))
     {
          $customer = $object->getCustomer();
          /*Insert Customer Data into Refer Account*/
          $data['email'] = $customer->getEmail();
          $id = Mage::getSingleton('reffersystem/refferemails')->load($data['email'])->getRefferalId();
          if(!empty($id))
          {
            $data['sign_up'] =1;
            try{
                Mage::getModel('reffersystem/refferemails')->load($id)->addData($data)->save();
              }
              catch (Exception $e) {
                  return;
              }
            /*Check For Sign Up Rules*/
            $checkRules = Mage::getModel('reffersystem/refferrule')->getSignUpRule($storeId);
            if($checkRules)
            {
                Mage::getModel('reffersystem/refferstatistics')->insertSatisticsData($checkRules,Mage::getModel('core/cookie')->get('email_refer_customer'));
            }
          }
          
     }

  }

  public function applyDiscount($observer)
  {
    $quote=$observer->getEvent()->getQuote();
    //Mage::log("Order: ".print_r($observer->debug(), true),null,'Order.log'); exit();
    if(Mage::helper('reffersystem')->getReferEnable() && Mage::helper('reffersystem')->getReferralEnable())
    {
      /*Check Id Customer Is Loged In*/
      if(Mage::getSingleton('customer/session')->isLoggedIn())
      {
        $customer = Mage::getSingleton('customer/session')->getCustomer();
        $email = $customer->getEmail();
        $refferal_id = Mage::getSingleton('reffersystem/refferemails')->load($email)->getRefferalId();
        if(!empty($refferal_id))
        {
            $model = Mage::getModel('reffersystem/refferemails')->load($refferal_id);
            $discount_get = $model->getDiscountGet();
            if(!$discount_get)
            {
              $apply_discount = true;
            }
            
        }
        elseif(Mage::getModel('core/cookie')->get('email_refer_customer') OR Mage::getModel('core/cookie')->get('broadcast_refer_customer'))
        {
            $apply_discount = true;
        }
      }

      elseif(Mage::getModel('core/cookie')->get('email_refer_customer') OR Mage::getModel('core/cookie')->get('broadcast_refer_customer'))
      {
          $apply_discount = true;
      }
      elseif(!Mage::getSingleton('customer/session')->isLoggedIn())
      {
        $customer = Mage::getModel('customer/customer')->load($quote->getCustomerId());
      }
          
         /* print_r($quote->getData()); exit();*/
          $quoteid=$quote->getId();
          /*Reffer Section*/
          $refer_model = Mage::getSingleton('reffersystem/refferstatistics')->load($customer->getEntityId());
          $refer_data = $refer_model->getData();
          if(!empty($refer_data))
          {
            /*Get Cart Total Method*/
            $cart_total_method = Mage::helper('reffersystem')->getPurchaseAmountCalculations();
            /*Get Maximum Discount Configuration*/
            $max_discount_config = Mage::helper('reffersystem')->getMaximumDiscount();
            /*Get Apply Cart Condition*/
            $cart_apply_condition = Mage::helper('reffersystem')->getCartCondition();
            /*Get Max Balance Condition*/
            $max_balance_condition = Mage::helper('reffersystem')->getCustomerMaxBalance();

            $refer_balance = $refer_model->getBalance();
            $refer_discounts = $refer_model->getActiveDiscount();
            /*If Customer Has Balance*/
            if($refer_balance!=0.00)
            {
                /*If Customer Has Min Balance Then Config*/
                if($refer_balance<=$max_balance_condition)
                {
                    $discountAmount = $refer_balance;
                }
                /*If Customer Has Greater Balance Then Config Balance */
                else
                {
                    $discountAmount = $max_balance_condition;
                }
                $discount_label = 'Refer Balance';
            }
            /*Apply Discounts*/
            elseif($refer_discounts!=0.00)
            {
              /*Cart Total Condition */
              if($cart_total_method==1)
              {
                  $cart_total = $quote->getBaseSubtotal();
              }
              elseif($cart_total_method==2)
              {
                  foreach($quote->getAllItems() as $pro)
                  {
                    $cart_total += $pro->getPriceInclTax();
                  }
              }
              /*Discount Configuration*/
              if($refer_discounts<=$max_discount_config)
              {
                $discount_percentage = $refer_discounts;
              }
              else
              {
                $discount_percentage = $max_discount_config;
              }

              $discountAmount = $cart_total * ($discount_percentage/100);
              $discount_label = 'Refer Discount';
            }
            if($quote->getBaseGrandTotal()>=$cart_apply_condition)
            {
              $apply_discount = true; 
            }
            else
            {
              $apply_discount = false;
            }

          }
          /*Referral Section*/
          else
          {

            $discount_rate = Mage::helper('reffersystem')->getReferralDiscountAmount();
            $discount_type = Mage::helper('reffersystem')->getReferralDiscountType();
            if($discount_type==1)
            {
              $discountAmount = $discount_rate;
            }
            elseif($discount_type==2)
            {
                $order_total = $quote->getBaseSubtotal();
                $percent = $order_total * ($discount_rate/100);
                $discountAmount = $percent;
            }

            $discount_label = 'Referral Discount';

          }
          if($apply_discount){
            if($quoteid) 
            {
            if($discountAmount>0) 
            {
              $total=$quote->getBaseSubtotal();
              $quote->setSubtotal(0);
              $quote->setBaseSubtotal(0);
              
              $quote->setSubtotalWithDiscount(0);
              $quote->setBaseSubtotalWithDiscount(0);

              $quote->setGrandTotal(0);
              $quote->setBaseGrandTotal(0);
              
              $canAddItems = $quote->isVirtual()? ('billing') : ('shipping'); 
              foreach ($quote->getAllAddresses() as $address) {
                  $address->setSubtotal(0);
                  $address->setBaseSubtotal(0);

                  $address->setGrandTotal(0);
                  $address->setBaseGrandTotal(0);

                  $address->collectTotals();

                  $quote->setSubtotal((float) $quote->getSubtotal() + $address->getSubtotal());
                  $quote->setBaseSubtotal((float) $quote->getBaseSubtotal() + $address->getBaseSubtotal());

                  $quote->setSubtotalWithDiscount(
                  (float) $quote->getSubtotalWithDiscount() + $address->getSubtotalWithDiscount());
                  $quote->setBaseSubtotalWithDiscount(
                  (float) $quote->getBaseSubtotalWithDiscount() + $address->getBaseSubtotalWithDiscount());
                  $quote->setGrandTotal((float) $quote->getGrandTotal() + $address->getGrandTotal());
                  $quote->setBaseGrandTotal((float) $quote->getBaseGrandTotal() + $address->getBaseGrandTotal());
                  $quote ->save(); 
                  $quote->setGrandTotal($quote->getBaseSubtotal()-$discountAmount)
                    ->setBaseGrandTotal($quote->getBaseSubtotal()-$discountAmount)
                    ->setSubtotalWithDiscount($quote->getBaseSubtotal()-$discountAmount)
                    ->setBaseSubtotalWithDiscount($quote->getBaseSubtotal()-$discountAmount)
                    ->save(); 
                  if($address->getAddressType()==$canAddItems) {
                   
                  $address->setSubtotalWithDiscount((float) $address->getSubtotalWithDiscount()-$discountAmount);
                  $address->setGrandTotal((float) $address->getGrandTotal()-$discountAmount);
                  $address->setBaseSubtotalWithDiscount((float) $address->getBaseSubtotalWithDiscount()-$discountAmount);
                  $address->setBaseGrandTotal((float) $address->getBaseGrandTotal()-$discountAmount);
                  if($address->getDiscountDescription()){
                    $address->setDiscountAmount(-($address->getDiscountAmount()-$discountAmount));
                    $address->setDiscountDescription($address->getDiscountDescription().','.$discount_label);
                    $address->setBaseDiscountAmount(-($address->getBaseDiscountAmount()-$discountAmount));
                  }else {
                    $address->setDiscountAmount(-($discountAmount));
                    $address->setDiscountDescription($discount_label);
                    $address->setBaseDiscountAmount(-($discountAmount));
                  }
                    $address->save();
                  }
                } 
                

                foreach($quote->getAllItems() as $item){
                 
                      $rat= $item->getPriceInclTax()/$total;
                      $ratdisc=$discountAmount;
                      $item->setDiscountAmount(($item->getDiscountAmount()+$ratdisc) * $item->getQty());
                      $item->setBaseDiscountAmount(($item->getBaseDiscountAmount()+$ratdisc) * $item->getQty())->save();
                    }
                  }
                }
          }
          }
  }

  public function referalCheckout($observer)
  {
       $order_id = $observer->getData('order_ids');
        
        $order = Mage::getModel('sales/order')->load($order_id);
      if(Mage::getSingleton('customer/session')->isLoggedIn())
      {
        $customer = Mage::getSingleton('customer/session')->getCustomer();
        $email = $customer->getEmail();
        $refferal_id = Mage::getSingleton('reffersystem/refferemails')->load($email)->getRefferalId();
        if(!empty($refferal_id))
        {
            $model = Mage::getModel('reffersystem/refferemails')->load($refferal_id);
            $data['purchase_qty'] = $model->getPurchaseQty() + count($order->getAllItems());
            $data['purchase_amount'] = $model->getPurchaseAmount() + $order->getGrandTotal();
            $data['discount_get'] = 1;
            $model->addData($data);
            $model->save();
            $refer_id = $model->getRefferCustomerId();
        }
        /*Remove Cookies*/
        if(Mage::getModel('core/cookie')->get('email_refer_customer') OR Mage::getModel('core/cookie')->get('broadcast_refer_customer') OR !empty($refer_id))
        {
          /*Save Order Data In Custom Table*/
          if(empty($refer_id))
            {
              if(Mage::getModel('core/cookie')->get('email_refer_customer'))
              {
                $refer_id = Mage::getModel('core/cookie')->get('email_refer_customer');
              }
              elseif(Mage::getModel('core/cookie')->get('broadcast_refer_customer'))
              {
                  $refer_id = Mage::getModel('core/cookie')->get('broadcast_refer_customer');
              }
          }
            $chk_data['refer_id'] = $refer_id;
            $chk_data['order_id'] = $order_id[0];
            $chk_model = Mage::getModel('reffersystem/reffercheckouts');
            $chk_model->setData($chk_data);
            $chk_model->save();
            /*Statics Data*/
            $stat_model = Mage::getModel('reffersystem/refferstatistics')->load($refer_id);
            $stat_data['qty_purchased'] = $stat_model->getQtyPurchased() + count($order->getAllItems());
            $stat_data['amount_purchased'] = $stat_model->getAmountPurchased() + $order->getGrandTotal();
            if(!empty($refer_id))
            {
              $stat_model->addData($stat_data);
              $stat_model->save();
              Mage::getModel('core/cookie')->delete('email_refer_customer');
              Mage::getModel('core/cookie')->delete('broadcast_refer_customer');
            }
            //print_r($chk_model->getData()); exit();
            Mage::getModel('core/cookie')->delete('email_refer_customer');
            Mage::getModel('core/cookie')->delete('broadcast_refer_customer');
        }
      }

  }

  /*Apply Rules When Order Status Changes*/
  public function orderSaveAefore($observer)
  {
      $event = $observer->getEvent();
      $order = $event->getOrder();
      if($order->getStatus()=='complete')
      {
          /*Check Order Data In Module Table*/
          $model = Mage::getSingleton('reffersystem/reffercheckouts')->load($order->getEntityId(),'order_id');
         /* print_r($model->getData());
          exit();*/
          $id = $model->getReferId();
          $chk_id = $model->getChkId();
          $chk_model = Mage::getModel('reffersystem/reffercheckouts')->load($chk_id);
          //print_r($chk_model->getData()); exit();
          /*Check For Discount For Number Of Items Rule*/
          $storeId = $order->getStoreId();
          $orderItemRule = Mage::getModel('reffersystem/refferrule')->getOrderItemRule($storeId);
          if($orderItemRule && !empty($id))
          {
             Mage::getModel('reffersystem/refferstatistics')->insertSatisticsDataByOrderRules($orderItemRule,$id,$order,$chk_model);
          }
          $orderAmountRule = Mage::getModel('reffersystem/refferrule')->getOrderAmountRule($storeId);
          
          if($orderAmountRule && !empty($id))
          {
             Mage::getModel('reffersystem/refferstatistics')->insertSatisticsDataByOrderRules($orderAmountRule,$id,$order,$chk_model);
          } 
      }
     
  }

  public function orderRefunded($observer)
  {
      $event = $observer->getEvent();
      $CreditMemo = $observer->getCreditmemo();
      $order      = $CreditMemo->getOrder();
      /*Check If Refer Get Discounts On Order*/
      $model = Mage::getSingleton('reffersystem/reffercheckouts')->load($order->getEntityId(),'order_id');
      //Mage::log("Order: ".print_r($order->debug(), true),null,'Order.log'); exit();
      if($model->getApplied()==1 && $model->getAmount()!=0.00)
      {
        /*Remove Discounts From Refer Statics*/
        $stat_model = Mage::getModel('reffersystem/refferstatistics')->load($model->getReferId());
        $stat_data['active_discount'] = $stat_model->getActiveDiscount() - $model->getAmount();
        $stat_data['qty_purchased'] = $stat_model->getQtyPurchased() - $order->getTotalItemCount();
        $stat_data['amount_purchased'] = $stat_model->getAmountPurchased() - $order->getBaseGrandTotal();
        $stat_data['updated_time'] = now();
        $stat_model->addData($stat_data)->save();
        
        /*Remove Discounts From Discounts Table*/
        
        Mage::getModel('reffersystem/refferdiscounts')->removeReferDiscounts($model->getAmount(),$model->getReferId());
        
        /*Update Refer Emails*/

        $email_model = Mage::getSingleton('reffersystem/refferemails')->load($order->getCustomerEmail());
        $email_data['purchase_qty'] =  $email_model->getPurchaseQty() - $order->getTotalItemCount();
        $email_data['purchase_amount'] = $email_model->getPurchaseAmount() - $order->getBaseGrandTotal();
        $email_model->addData($email_data)->save();
               
      }

      /*If Refer Order Refunded And Has Refer Discount Or Balance*/
        $discount_label = $order->getDiscountDescription();
        $discount_amount  = $order->getDiscountAmount();
        $customer_id = $order->getCustomerId();
        $customer_email = $order->getCustomerEmail();
        if($discount_label=='Refer Balance')
        {
          /*Commit a Transction And Deduct Balance From Refer Account*/
          $discount_amount = -1 * $discount_amount;
         
          Mage::getModel('reffersystem/refferstatistics')->addBalance($customer_id,$customer_email,$discount_amount,$order->getBaseGrandTotal());
        }
        elseif($discount_label=='Refer Discount')
        {
          /*Deduct Discount From Customer Balance*/

          $cart_total_method = Mage::helper('reffersystem')->getPurchaseAmountCalculations();
          if($cart_total_method==1)
          {
              $cart_total = $order->getBaseSubtotal();
          }
          elseif($cart_total_method==2)
          {
              foreach($order->getAllItems() as $pro)
              {
                $cart_total += $pro->getPriceInclTax();
              }
          }

          $discount_amount = -1 * $discount_amount;
          $percent = ($discount_amount * 100) / $cart_total;
          /*print_r($percent); exit();*/
          Mage::getModel('reffersystem/refferstatistics')->addDiscount($customer_id,$customer_email,$percent,$order->getBaseGrandTotal());
        }

        
  }

  public function referCheckout($observer)
  {
      $order  = $observer->getOrder();
      $quote  = $order->getQuote();

      // if($order->getDeductBalance()){ 
      //   //check if flag is already set.
      //   return;
      // }
      /*Check If Order State Is New*/
      if($order->getState() =='new')
      {
        /*Check that if Order Has Refer Balance Or Refer Discount*/
         $discount_label = $order->getDiscountDescription();
         $discount_amount  = $order->getDiscountAmount();
        $customer_id = $order->getCustomerId();
        $customer_email = $order->getCustomerEmail();
        if($discount_label=='Refer Balance')
        {
          /*Commit a Transction And Deduct Balance From Refer Account*/
          Mage::getModel('reffersystem/refferstatistics')->deductBalance($customer_id,$customer_email,$discount_amount,$order->getBaseGrandTotal());
          $order->setDeductBalance(true);
        }
        elseif($discount_label=='Refer Discount')
        {
          /*Deduct Discount From Customer Balance*/

          $cart_total_method = Mage::helper('reffersystem')->getPurchaseAmountCalculations();
          if($cart_total_method==1)
          {
              $cart_total = $order->getBaseSubtotal();
          }
          elseif($cart_total_method==2)
          {
              foreach($order->getAllItems() as $pro)
              {
                $cart_total += $pro->getPriceInclTax();
              }
          }

          $discount_amount = -1 * $discount_amount;
          $percent = ($discount_amount * 100) / $cart_total;
          /*print_r($percent); exit();*/
          Mage::getModel('reffersystem/refferstatistics')->deductDiscount($customer_id,$customer_email,$percent,$order->getBaseGrandTotal());
          $order->setDeductBalance(true);
        }
      }
      
  }
}
