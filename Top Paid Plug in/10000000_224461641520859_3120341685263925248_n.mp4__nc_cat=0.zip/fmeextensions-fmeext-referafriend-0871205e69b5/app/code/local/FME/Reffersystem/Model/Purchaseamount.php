<?php

/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Model_Purchaseamount extends Mage_Core_Model_Abstract
{
  
    const ITEM	= 1;
    const ITEM_TAX	= 2;

    static public function toOptionArray()
    {
        return array(
            self::ITEM    => Mage::helper('reffersystem')->__('Item'),
            self::ITEM_TAX   => Mage::helper('reffersystem')->__('Item + Tax')
        );
    }
    
}