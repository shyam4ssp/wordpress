<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Model_Refferdiscounts extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('reffersystem/refferdiscounts');
    }

    public function insetReferDiscount($discount,$customer_id)
    {
    	return $this->_getResource()->insetReferDiscount($discount,$customer_id);
    }

    public function removeReferDiscounts($discount,$customer_id)
    {
    	return $this->_getResource()->removeReferDiscounts($discount,$customer_id);
    }
}