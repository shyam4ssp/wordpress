<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Model_Refferrule extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('reffersystem/refferrule');
    }

    public function getSignUpRule($storeId)
    {
        return $this->_getResource()->getSignUpRule($storeId);
    }

    public function getOrderItemRule($storeId)
    {
    	return $this->_getResource()->getOrderItemRule($storeId);
    }

    public function getOrderAmountRule($storeId)
    {
        return $this->_getResource()->getOrderAmountRule($storeId);
    }

    
}