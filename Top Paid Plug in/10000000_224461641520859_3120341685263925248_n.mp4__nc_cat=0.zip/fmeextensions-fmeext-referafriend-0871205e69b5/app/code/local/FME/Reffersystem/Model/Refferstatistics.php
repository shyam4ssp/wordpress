<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class FME_Reffersystem_Model_Refferstatistics extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('reffersystem/refferstatistics');
    }

    public function insertSatisticsData($checkRules,$customer_id)
    {
		return $this->_getResource()->insertSatisticsData($checkRules,$customer_id);
	}

	public function insertSatisticsDataByOrderRules($checkRules,$customer_id,$order,$chk_model)
	{
		return $this->_getResource()->insertSatisticsDataByOrderRules($checkRules,$customer_id,$order,$chk_model);
	}

	public function adminAddDiscounts($customer_id,$discount)
	{
		return $this->_getResource()->adminAddDiscounts($customer_id,$discount);
	}

	public function adminAddBalance($customer_id,$balance)
	{
		return $this->_getResource()->adminAddBalance($customer_id,$balance);
	}

	public function deductBalance($customer_id,$customer_email,$discount_amount,$money)
	{
		return $this->_getResource()->deductBalance($customer_id,$customer_email,$discount_amount,$money);
	}

	public function deductDiscount($customer_id,$customer_email,$percent,$money)
	{
		return $this->_getResource()->deductDiscount($customer_id,$customer_email,$percent,$money);
	}

	public function addBalance($customer_id,$customer_email,$discount_amount,$money)
	{
		return $this->_getResource()->addBalance($customer_id,$customer_email,$discount_amount,$money);
	}

	public function addDiscount($customer_id,$customer_email,$percent,$money)
	{
		return $this->_getResource()->addDiscount($customer_id,$customer_email,$percent,$money);
	}
}