<?php

/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     support@fmeextensions.com
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class FME_Reffersystem_Adminhtml_RefferdiscountsController extends Mage_Adminhtml_Controller_Action {

    protected function _initAction() {
        $this->loadLayout()
                ->_setActiveMenu('reffersystem/items')
                ->_addBreadcrumb(Mage::helper('adminhtml')->__('Discounts Manager'), Mage::helper('adminhtml')->__('Discounts Manager'));

        return $this;
    }

    public function indexAction() {
        $this->_initAction()
                ->renderLayout();
    }

    protected function _isAllowed() {
        return true;
    }
    
    public function editAction() {
        $id = $this->getRequest()->getParam('id');
        $model = Mage::getModel('reffersystem/refferdiscounts')->load($id);

        if ($model->getId() || $id == 0) {
            $data = Mage::getSingleton('adminhtml/session')->getFormData(true);
            if (!empty($data)) {
                $model->setData($data);
            }

            Mage::register('refferdiscounts_data', $model);

            $this->loadLayout();
            $this->_setActiveMenu('reffersystem/items');

            $this->_addBreadcrumb(Mage::helper('adminhtml')->__('Discounts Manager'), Mage::helper('adminhtml')->__('Discounts Manager'));
            $this->_addBreadcrumb(Mage::helper('adminhtml')->__('Discounts'), Mage::helper('adminhtml')->__('Discounts'));

            $this->getLayout()->getBlock('head')->setCanLoadExtJs(true);

            $this->_addContent($this->getLayout()->createBlock('reffersystem/adminhtml_refferdiscounts_edit'))
            ;

            $this->renderLayout();
        } else {
            Mage::getSingleton('adminhtml/session')->addError(Mage::helper('reffersystem')->__('Discounts does not exist'));
            $this->_redirect('*/*/');
        }
    }

    public function newAction() {
        $this->_forward('edit');
    }

    public function saveAction() {
        if ($data = $this->getRequest()->getPost()) {
            /* print_r($data); exit(); */

            try {
                if (!$this->getRequest()->getParam('id')) {
                    $customers = $data['customer'];
                    foreach ($customers as $customer) {
                        $customer_model = Mage::getModel('customer/customer')->load($customer);
                        /* If Customer Is Exits in Table */
                        $discount_model = Mage::getSingleton('reffersystem/refferdiscounts')->load($customer, 'customer_id');
                        if ($discount_model->getDiscountId() != NULL) {

                            $discount_data['discount_amount'] = $data['discount_amount'];
                            $d_model = Mage::getModel('reffersystem/refferdiscounts')->load($discount_model->getDiscountId());
                            $d_model->addData($discount_data)->save();
                        } else {

                            $data['customer_id'] = $customer_model->getEntityId();
                            $data['customer_email'] = $customer_model->getEmail();
                            $data['trigger'] = 0;
                            $model = Mage::getModel('reffersystem/refferdiscounts');
                            $model->setData($data)
                                    ->setId($this->getRequest()->getParam('id'));

                            if ($model->getCreatedTime == NULL || $model->getUpdateTime() == NULL) {
                                $model->setCreatedTime(now());
                            } else {
                                
                            }

                            $model->save();
                        }
                        Mage::getModel('reffersystem/refferstatistics')->adminAddDiscounts($customer, $data['discount_amount']);
                    }
                } else {
                    $model = Mage::getModel('reffersystem/refferdiscounts');
                    $model->setData($data)
                            ->setId($this->getRequest()->getParam('id'));

                    if ($model->getCreatedTime == NULL || $model->getUpdateTime() == NULL) {
                        $model->setCreatedTime(now());
                    } else {
                        
                    }

                    $model->save();
                    Mage::getModel('reffersystem/refferstatistics')->adminAddDiscounts($data['customer_id'], $data['discount_amount']);
                }
                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('reffersystem')->__('Discounts was successfully saved'));
                Mage::getSingleton('adminhtml/session')->setFormData(false);

                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('*/*/edit', array('id' => $model->getId()));
                    return;
                }
                $this->_redirect('*/*/');
                return;
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                Mage::getSingleton('adminhtml/session')->setFormData($data);
                $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
                return;
            }
        }
        Mage::getSingleton('adminhtml/session')->addError(Mage::helper('reffersystem')->__('Unable to find item to save'));
        $this->_redirect('*/*/');
    }

    public function deleteAction() {
        if ($this->getRequest()->getParam('id') > 0) {
            try {
                $model = Mage::getModel('reffersystem/refferdiscounts');

                $model->setId($this->getRequest()->getParam('id'))
                        ->delete();

                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Discounts was successfully deleted'));
                $this->_redirect('*/*/');
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
            }
        }
        $this->_redirect('*/*/');
    }

    public function massDeleteAction() {
        $refferdiscountsIds = $this->getRequest()->getParam('refferdiscounts');
        if (!is_array($refferdiscountsIds)) {
            Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__('Please select item(s)'));
        } else {
            try {
                foreach ($refferdiscountsIds as $refferdiscountsId) {
                    $refferdiscounts = Mage::getModel('reffersystem/refferdiscounts')->load($refferdiscountsId);
                    $refferdiscounts->delete();
                }
                Mage::getSingleton('adminhtml/session')->addSuccess(
                        Mage::helper('adminhtml')->__(
                                'Total of %d record(s) were successfully deleted', count($refferdiscountsIds)
                        )
                );
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
            }
        }
        $this->_redirect('*/*/index');
    }

    public function exportCsvAction() {
        $fileName = 'reffersystem.csv';
        $content = $this->getLayout()->createBlock('reffersystem/adminhtml_refferdiscounts_grid')
                ->getCsv();

        $this->_sendUploadResponse($fileName, $content);
    }

    public function exportXmlAction() {
        $fileName = 'reffersystem.xml';
        $content = $this->getLayout()->createBlock('reffersystem/adminhtml_refferdiscounts_grid')
                ->getXml();

        $this->_sendUploadResponse($fileName, $content);
    }

    protected function _sendUploadResponse($fileName, $content, $contentType = 'application/octet-stream') {
        $response = $this->getResponse();
        $response->setHeader('HTTP/1.1 200 OK', '');
        $response->setHeader('Pragma', 'public', true);
        $response->setHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0', true);
        $response->setHeader('Content-Disposition', 'attachment; filename=' . $fileName);
        $response->setHeader('Last-Modified', date('r'));
        $response->setHeader('Accept-Ranges', 'bytes');
        $response->setHeader('Content-Length', strlen($content));
        $response->setHeader('Content-type', $contentType);
        $response->setBody($content);
        $response->sendResponse();
    }

    public function gridAction() {
        $this->getResponse()->setBody($this->getLayout()->createBlock('reffersystem/adminhtml_customer_grid')->toHtml());
    }

}
