<?php

/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class FME_Reffersystem_Adminhtml_RefferstatisticsController extends Mage_Adminhtml_Controller_Action {

    protected function _initAction() {
        $this->loadLayout()
                ->_setActiveMenu('reffersystem/items')
                ->_addBreadcrumb(Mage::helper('adminhtml')->__('Statistics'), Mage::helper('adminhtml')->__('Statistics'));

        return $this;
    }

    public function indexAction() {
        $this->_initAction()
                ->renderLayout();
    }

    protected function _isAllowed() {
        return true;
    }
    
    public function exportCsvAction() {
        $fileName = 'reffersystem.csv';
        $content = $this->getLayout()->createBlock('reffersystem/adminhtml_refferstatistics_grid')
                ->getCsv();

        $this->_sendUploadResponse($fileName, $content);
    }

    public function exportXmlAction() {
        $fileName = 'reffersystem.xml';
        $content = $this->getLayout()->createBlock('reffersystem/adminhtml_refferstatistics_grid')
                ->getXml();

        $this->_sendUploadResponse($fileName, $content);
    }

    protected function _sendUploadResponse($fileName, $content, $contentType = 'application/octet-stream') {
        $response = $this->getResponse();
        $response->setHeader('HTTP/1.1 200 OK', '');
        $response->setHeader('Pragma', 'public', true);
        $response->setHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0', true);
        $response->setHeader('Content-Disposition', 'attachment; filename=' . $fileName);
        $response->setHeader('Last-Modified', date('r'));
        $response->setHeader('Accept-Ranges', 'bytes');
        $response->setHeader('Content-Length', strlen($content));
        $response->setHeader('Content-type', $contentType);
        $response->setBody($content);
        $response->sendResponse();
    }

    public function gridAction() {
       $this->getResponse()->setBody($this->getLayout()->createBlock('reffersystem/adminhtml_refferstatistics_grid')->toHtml());
    }

}
