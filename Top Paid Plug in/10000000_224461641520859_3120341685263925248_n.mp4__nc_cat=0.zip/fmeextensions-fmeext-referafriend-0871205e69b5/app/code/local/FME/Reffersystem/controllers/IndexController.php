<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class FME_Reffersystem_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {	
    	
    	if(!Mage::getSingleton('customer/session')->isLoggedIn()) 
    	{
         	Mage::getSingleton('core/session')->addError(Mage::helper('reffersystem')->__('Please login to view the page'));
         	$this->norouteAction();
		}
		else
		{
			if(!Mage::helper('reffersystem')->getReferEnable())
			{  
				Mage::getSingleton('core/session')->addError(Mage::helper('reffersystem')->__('Sorry This Feature is disabled.'));
         		$this->norouteAction(); 
         	}
         	else
         	{
         		$this->loadLayout();     
		   		$this->renderLayout();
		   	}
		}		
		
    }

    /*If Customer Come From BoradCast Link*/
    public function broadcastAction()
    {
    	$links = explode("refd=",$_SERVER['REQUEST_URI']);
       if($links[1] !='')
       { 
       		Mage::app();
  			$cookie = Mage::getSingleton('core/cookie');
  			$referId =  Mage::helper('reffersystem')->decryptBoradCastLink($links[1]);
  			$cookie->set('broadcast_refer_customer', $referId);
  		}
  			Mage::getSingleton('core/session')->addSuccess(Mage::helper('reffersystem')->__('Become Customer And Get Discounts'));
  			Mage::app()->getFrontController()->getResponse()->setRedirect(Mage::getUrl('customer/account'));
    }

    /*If Customer Come From Email Link*/
    public function maillinkAction()
    {
    	$links = explode("refd=",$_SERVER['REQUEST_URI']);
    	if($links[1] !='')
       	{ 
	    	$referlinks =  Mage::helper('reffersystem')->decryptBoradCastLink($links[1]);
	    	$referlarray = explode('&', $referlinks);

	       if(!empty($referlarray))
	       { 
	       		Mage::app();
	  			$cookie = Mage::getSingleton('core/cookie');
	  			$referId =  $referlarray[0];
	  			if(Mage::getModel('core/cookie')->get('broadcast_refer_customer'))
	  			{
	  				$cookie->delete('broadcast_refer_customer');
	  			}
	  			$email = $referlarray[1];
	  			$cookie->set('email_refer_customer', $referId);
	  			$data['confirmed'] = 1;
	  			$id = Mage::getSingleton('reffersystem/refferemails')->load($email)->getRefferalId();
	  			Mage::getModel('reffersystem/refferemails')->load($id)->addData($data)->save();
	  		}
	  	}
	  			Mage::getSingleton('core/session')->addSuccess(Mage::helper('reffersystem')->__('Become Customer And Get Discounts'));
	  			Mage::app()->getFrontController()->getResponse()->setRedirect(Mage::getUrl('customer/account'));

    }
    public function emailReferAction()
    {
    	
    	if ($data = $this->getRequest()->getPost()) 
    	{
    		
				
    		$customer = Mage::getSingleton('customer/session')->getCustomer();
            $id = $customer->getId();
            $sender_email = Mage::helper('reffersystem')->getSenderEmail();
            $sender_name = Mage::helper('reffersystem')->getSenderName();
            $subject = $data['subject'];
            $message = $data['comment'];
            $emails = explode(",", $data['email']);
            if(count($emails) > 4) {
    			$this->getResponse()->setBody(json_encode(array("error","Maximum 4 No of email allowed.")));
        		
    		}
    		$i = 0;
    		foreach ($emails as $email) 
        	{
        		/*Check If Email Is Already Reffered*/
        		$reffered_email = Mage::getSingleton('reffersystem/refferemails')->load($email)->getEmail();
        		if(empty($reffered_email))
        		{

	        		$new_url =  Mage::helper('reffersystem')->encryptBoradCastLink($id.'&'.$email);
					//$ref_url = $url."index/maillink/?refd=".$new_url;
					if (Mage::app()->isSingleStoreMode()){
						$url =  Mage::getUrl('reffersystem/index/maillink',array('_query'=>array('refd'=>$new_url)));
					}
					if (Mage::app()->getStore()->getCode() != 'default')
					{
						$url = Mage::getUrl('reffersystem/index/maillink', array('_secure'=>Mage::app()->getStore(true)->isCurrentlySecure(),'_store_to_url' => true, '_store' => Mage::app()->getStore()->getId(),'_query'=>array('refd'=>$new_url)));
					}
					else
					{
						$url = Mage::getUrl('reffersystem/index/maillink',array('_secure'=>Mage::app()->getStore(true)->isCurrentlySecure()));
					}
					$ref_url = $url;
					$toEmail = $email;
					$emailTemplate  = Mage::getModel('core/email_template')
	                                  	->loadDefault(Mage::helper('reffersystem')->getEmailTemplate()); 
	                $emailTemplateVariables = array();
	              	$emailTemplateVariables['msg'] = $message;
	              	$emailTemplateVariables['url'] = $ref_url ;
	              	$emailTemplate->setSenderName($sender_name);
	          		$emailTemplate->setSenderEmail($sender_email);
	          		$emailTemplate->setTemplateSubject($subject);
	          		$processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
	              try
	              {
	              	$emailTemplate->send($email,'Friend', $emailTemplateVariables);
	              	$send = true;
	              	/*Save Data In Refer Table*/
	              	if($send=true)
	              	{
	              		$refer_data['email'] = $email;
	              		$refer_data['message'] = $message;
	              		$refer_data['subject'] = $subject;
	              		$refer_data['store_id'] = Mage::app()->getStore()->getId();
	              		$refer_data['reffer_customer_id'] = $id;
	              		$refer_data['created_time'] = now();
	              		$model = Mage::getModel('reffersystem/refferemails');
	              		$model->setData($refer_data);
	              		$model->save();
	              		$i++;
	              	}

	              }
	              catch(Exception $error) {
	                    $sent = false;
	                  $this->getResponse()->setBody(json_encode(array("error",$error)));
	              }
	          	}
	          	else
	          	{
	          		$refferdemails[] = $reffered_email;
	          	}
              
        	}
        	if(!empty($refferdemails))
        	{

        		$this->getResponse()->setBody(json_encode(array("error","The Email Address Already Refered  ".implode(",",$refferdemails))));
        	}
        	if($i!=0){
              			$this->getResponse()->setBody(json_encode(array("success","Email Sent successfully..")));
               }else{
               $this->getResponse()->setBody(json_encode(array("error","Email Not Sent due to some error..")));
            }

    	}
    }
}