<?php
/**
 * @category   FME
 * @package    FME_Reffersystem
 * @author     Syed Shaheer Ali <support@fmeextensions.com>
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

$installer = $this;

$installer->startSetup();

$installer->run("

DROP TABLE IF EXISTS {$this->getTable('reffer_checkouts')};
CREATE TABLE {$this->getTable('reffer_checkouts')} (
  `chk_id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `refer_id` int(10) unsigned NOT NULL,
  `order_id` int(30) NOT NULL DEFAULT '0',
  `amount` double(15,2) NOT NULL DEFAULT '0.00',
  `applied` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`chk_id`),
  KEY `reffer_checkouts_ibfk_1` (`refer_id`),
  CONSTRAINT `reffer_checkouts_ibfk_1` FOREIGN KEY (`refer_id`) REFERENCES {$this->getTable('customer_entity')} (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `reffer_discounts` */

DROP TABLE IF EXISTS {$this->getTable('reffer_discounts')};
CREATE TABLE {$this->getTable('reffer_discounts')} (
  `discount_id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(15) unsigned NOT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `discount_amount` float(30,2) NOT NULL DEFAULT '0.00',
  `trigger` int(10) NOT NULL DEFAULT '0',
  `comments` varchar(255) DEFAULT NULL,
  `website_id` int(15) NOT NULL DEFAULT '0',
  `created_time` datetime DEFAULT NULL,
  PRIMARY KEY (`discount_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `reffer_discounts_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES {$this->getTable('customer_entity')} (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `reffer_emails` */

DROP TABLE IF EXISTS {$this->getTable('reffer_emails')};
CREATE TABLE {$this->getTable('reffer_emails')} (
  `refferal_id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `message` text,
  `subject` varchar(255) DEFAULT NULL,
  `store_id` int(10) NOT NULL DEFAULT '0',
  `sign_up` int(10) NOT NULL DEFAULT '0',
  `confirmed` int(10) NOT NULL DEFAULT '0',
  `reffer_customer_id` int(10) unsigned NOT NULL,
  `discount_get` int(10) NOT NULL DEFAULT '0',
  `created_time` datetime DEFAULT NULL,
  `purchase_qty` int(15) NOT NULL DEFAULT '0',
  `purchase_amount` int(15) NOT NULL DEFAULT '0',
  PRIMARY KEY (`refferal_id`),
  KEY `customer_id` (`email`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Table structure for table `reffer_rule` */

DROP TABLE IF EXISTS {$this->getTable('reffer_rule')};
CREATE TABLE {$this->getTable('reffer_rule')} (
  `rule_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(255) DEFAULT NULL,
  `rule_type` int(10) NOT NULL DEFAULT '0',
  `priority` int(10) NOT NULL DEFAULT '0',
  `discount_type` int(10) NOT NULL DEFAULT '0',
  `discount_amount` int(50) NOT NULL DEFAULT '0',
  `active_from` datetime DEFAULT NULL,
  `target` int(10) NOT NULL DEFAULT '0',
  `process_rule` int(10) NOT NULL DEFAULT '0',
  `bouns` int(50) NOT NULL DEFAULT '0',
  `created_time` datetime DEFAULT NULL,
  PRIMARY KEY (`rule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Table structure for table `reffer_statistics` */

DROP TABLE IF EXISTS {$this->getTable('reffer_statistics')};
CREATE TABLE {$this->getTable('reffer_statistics')} (
  `customer_id` int(15) unsigned NOT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `reg_reffarals` int(30) NOT NULL DEFAULT '0',
  `qty_purchased` int(30) NOT NULL DEFAULT '0',
  `amount_purchased` int(30) NOT NULL DEFAULT '0',
  `balance` int(30) NOT NULL DEFAULT '0',
  `active_discount` float(15,2) NOT NULL DEFAULT '0.00',
  `money_spent` int(255) DEFAULT '0',
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `reffer_statistics_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES {$this->getTable('customer_entity')} (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `reffer_stores` */

DROP TABLE IF EXISTS {$this->getTable('reffer_stores')};
CREATE TABLE {$this->getTable('reffer_stores')} (
 `st_id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `rule_id` int(15) unsigned NOT NULL,
  `store_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`st_id`),
  KEY `FK_rule_store` (`rule_id`),
  CONSTRAINT `FK_rule_store` FOREIGN KEY (`rule_id`) REFERENCES {$this->getTable('reffer_rule')} (`rule_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Table structure for table `reffer_transactions` */

DROP TABLE IF EXISTS {$this->getTable('reffer_transactions')};
CREATE TABLE {$this->getTable('reffer_transactions')} (
  `trans_id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(15) unsigned NOT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `balance` int(30) NOT NULL DEFAULT '0',
  `comments` varchar(255) DEFAULT NULL,
  `website_id` int(15) NOT NULL DEFAULT '0',
  `created_time` datetime DEFAULT NULL,
  PRIMARY KEY (`trans_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `reffer_transactions_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES {$this->getTable('customer_entity')} (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    ");

$installer->endSetup(); 