<?php

namespace Moip\Contracts;

use Requests_Auth;

/**
 * Interface Authentication.
 */
interface Authentication extends Requests_Auth
{
}
