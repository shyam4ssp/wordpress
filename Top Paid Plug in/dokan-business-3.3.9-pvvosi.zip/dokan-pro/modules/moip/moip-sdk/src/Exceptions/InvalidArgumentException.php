<?php

namespace Moip\Exceptions;

use RuntimeException;

/**
 * Class InvalidArgumentException.
 */
class InvalidArgumentException extends RuntimeException
{
}
