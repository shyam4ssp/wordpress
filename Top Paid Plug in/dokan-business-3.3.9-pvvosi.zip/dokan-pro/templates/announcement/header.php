<?php
/**
 * Dokan Announcement Header Template
 *
 * @since 2.4
 *
 * @package dokan
 */
?>
 <header class="dokan-dashboard-header dokan-clearfix">
    <span class="left-header-content">
        <h1 class="entry-title"><?php _e( 'Announcement', 'dokan' ); ?></h1>
    </span>
</header>
