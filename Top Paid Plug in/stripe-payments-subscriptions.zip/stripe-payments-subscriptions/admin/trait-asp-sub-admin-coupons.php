<?php

trait ASP_Sub_Admin_Coupons {

	public function save_coupon( $coupon_id, $coupon ) {
		$sub_applied_for = isset( $coupon['sub_applied_for'] ) ? $coupon['sub_applied_for'] : false;
		update_post_meta( $coupon_id, 'asp_sub_applied_for', $sub_applied_for );
		$sub_applied_for_months = isset( $coupon['sub_applied_for_months'] ) ? intval( $coupon['sub_applied_for_months'] ) : 1;
		update_post_meta( $coupon_id, 'asp_sub_applied_for_months', $sub_applied_for_months );
	}

	public function add_edit_coupon( $coupon_id ) {
		$sub_applied_for        = get_post_meta( $coupon_id, 'asp_sub_applied_for', true );
		$sub_applied_for_months = get_post_meta( $coupon_id, 'asp_sub_applied_for_months', true );
		$sub_applied_for_months = empty( $sub_applied_for_months ) ? 1 : $sub_applied_for_months;
		?>
	<tr>
		<th scope="row"><?php esc_html_e( 'Subscriptions Settings', 'asp-sub' ); ?></th>
		<td>
		<p>Coupon discount applied for:</p>
		<label><input type="radio" name="asp_coupon[sub_applied_for]" value="forever"<?php echo ! $coupon_id || ! $sub_applied_for || 'forever' === $sub_applied_for ? ' checked' : ''; ?>> <?php esc_html_e( 'All plan payments', 'asp-sub' ); ?></label>
		<br />
		<label><input type="radio" name="asp_coupon[sub_applied_for]" value="once"<?php echo 'once' === $sub_applied_for ? ' checked' : ''; ?>> <?php esc_html_e( 'First plan payment only', 'asp-sub' ); ?></label>
		<br />
		<label><input type="radio" name="asp_coupon[sub_applied_for]" value="repeating"<?php echo 'repeating' === $sub_applied_for ? ' checked' : ''; ?>> <?php echo sprintf( esc_html__( 'All plan payments for %s month(s)', 'asp-sub' ), '<input type="number" name="asp_coupon[sub_applied_for_months]" style="width: 4em;" value="' . esc_attr( $sub_applied_for_months ) . '">' ); ?></label>
		<p class="description"><?php esc_html_e( 'Specify how coupon discount should be applied to subscription payments.', 'asp-sub' ); ?></p>
		<p class="description" id="asp-sub-all-off-coupons-descr" style="display:none;">
			<?php esc_html_e( 'Note: all-off coupons can only be applied for all plan payments.', 'asp-sub' ); ?>
		</p>
		</td>
	</tr>
	<script>
		var aspSubIsAllOffCoupon = false;
		function asp_sub_check_all_off_coupon() {
			if (jQuery('input[name="asp_coupon[discount]"]').val() === '100' && jQuery('select[name="asp_coupon[discount_type]"]').val()==='perc') {
				jQuery('input[name="asp_coupon[sub_applied_for]"][value=once]').prop('disabled', true);
				jQuery('input[name="asp_coupon[sub_applied_for]"][value=repeating]').prop('disabled', true);
				jQuery('input[name="asp_coupon[sub_applied_for_months]"]').prop('disabled', true);
				jQuery('input[name="asp_coupon[sub_applied_for]"][value=forever]').prop('checked', true);
				jQuery('#asp-sub-all-off-coupons-descr').slideDown('fast');
				aspSubIsAllOffCoupon = true;
			} else if (aspSubIsAllOffCoupon) {
				jQuery('input[name="asp_coupon[sub_applied_for]"][value=once]').prop('disabled', false);
				jQuery('input[name="asp_coupon[sub_applied_for]"][value=repeating]').prop('disabled', false);
				jQuery('input[name="asp_coupon[sub_applied_for_months]"]').prop('disabled', false);
				jQuery('#asp-sub-all-off-coupons-descr').slideUp('fast');
				aspSubIsAllOffCoupon = false;
			}
		}
		jQuery('input[name="asp_coupon[discount]"]').change(function() {
			asp_sub_check_all_off_coupon();
		});
		jQuery('select[name="asp_coupon[discount_type]"]').change(function() {
			asp_sub_check_all_off_coupon();
		});
		jQuery(document).ready(function () {
			asp_sub_check_all_off_coupon();
		});
	</script>

		<?php
	}
}
