<?php

class ASPSUB_stripe_plans {

	protected static $instance = null;
	protected $last_error      = false;
	protected $asp_main;
	protected $asp_sub_main;
	public $ProdName = 'Stripe Payments Subs Addon Product #%d (%s)';

	public function __construct( $is_live ) {
		self::$instance = $this;

		ASPMain::load_stripe_lib();
		$this->asp_main     = AcceptStripePayments::get_instance();
		$this->asp_sub_main = ASPSUB_main::get_instance();
		if ( $is_live ) {
			$key = $this->asp_main->APISecKeyLive;
		} else {
			$key = $this->asp_main->APISecKeyTest;
		}
		try {
			if ( ASPSub_Utils::use_internal_api() ) {
				$api = ASP_Stripe_API::get_instance();
				$api->set_api_key( $key );
				$api->set_param( 'throw_exception', true );
			}
			\Stripe\Stripe::setApiKey( $key );
		} catch ( Exception $e ) {
			$this->last_error = $e->getMessage();
		}
	}

	public static function get_instance( $is_live = false ) {

		// If the single instance hasn't been set, set it now.
		if ( null === self::$instance ) {
			self::$instance = new self( $is_live );
		}

		return self::$instance;
	}

	public function get_last_error() {
		return $this->last_error;
	}

	public function create( $opts, $post_id ) {
		update_option( 'asp_sub_plans_cache', '' );
		$metadata         = array(
			'created_by' => 'asp_sub_plugin',
			'plan_id'    => $post_id,
			'created_on' => time(),
			'uid'        => $this->asp_sub_main->get_uid(),
		);
		$opts['interval'] = rtrim( $opts['interval'], 's' );
		$opts['product']  = array(
			'name'     => html_entity_decode( get_the_title( $post_id ) ),
			'metadata' => $metadata,
		);
		if ( ! in_array( strtoupper( $opts['currency'] ), $this->asp_main->zeroCents, true ) ) {
			$opts['amount'] = intval( round( $opts['amount'] * 100, 2 ) );
		}
		$opts['metadata'] = $metadata;
		try {
			$plan = \Stripe\Plan::create( $opts );
		} catch ( Exception $e ) {
			$this->last_error = $e->getMessage();
			return false;
		}
		return $plan;
	}

	public function update( $opts, $post_id ) {
		update_option( 'asp_sub_plans_cache', '' );
		try {
			$plan_prod_id = get_post_meta( $post_id, 'asp_sub_stripe_plan_prod_id', true );
			$prod_name    = html_entity_decode( get_the_title( $post_id ) );
			if ( ASPSUB_Utils::use_internal_api() ) {
				$api     = ASP_Stripe_API::get_instance();
				$product = $api->post( 'products/' . $plan_prod_id, array( 'name' => $prod_name ) );
			} else {
				$product       = \Stripe\Product::retrieve( $plan_prod_id );
				$product->name = $prod_name;
				$product->save();
			}
		} catch ( Exception $e ) {
			$this->last_error = $e->getMessage();
			return false;
		}

		try {
			$stripe_plan_id = get_post_meta( $post_id, 'asp_sub_stripe_plan_id', true );
			if ( ASPSUB_Utils::use_internal_api() ) {
				$api  = ASP_Stripe_API::get_instance();
				$plan = $api->post(
					'plans/' . $stripe_plan_id,
					array(
						'nickname'          => $opts['nickname'],
						'trial_period_days' => $opts['trial_period_days'],
					)
				);
			} else {
				$plan                    = \Stripe\Plan::retrieve( $stripe_plan_id );
				$plan->nickname          = $opts['nickname'];
				$plan->trial_period_days = $opts['trial_period_days'];
				$plan->save();
			}
		} catch ( Exception $e ) {
			$this->last_error = $e->getMessage();
			return false;
		}
		return $plan;
	}

	public function delete( $post_id ) {
		update_option( 'asp_sub_plans_cache', '' );
		$plan_id = get_post_meta( $post_id, 'asp_sub_stripe_plan_id', true );
		try {
			if ( ASPSUB_Utils::use_internal_api() ) {
				$api  = ASP_Stripe_API::get_instance();
				$plan = $api->post( 'plans/' . $plan_id, array(), 'DELETE' );
			}
			$plan = \Stripe\Plan::retrieve( $plan_id );
			$plan->delete();
		} catch ( Exception $e ) {
			$this->last_error = $e->getMessage();
			return false;
		}
		return $plan;
	}

}
