<?php

class ASPSUB_Utils {

	protected static $instance = null;
	private $sub_main;
	protected static $min_core_ver_for_internal_api = '2.0.51';

	public static function get_instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function __construct() {
		self::$instance = $this;

		$this->sub_main = ASPSUB_main::get_instance();

		ASPMain::load_stripe_lib();

		if ( wp_doing_ajax() && is_admin() ) {
			$this->add_ajax_hooks();
		}

		if ( function_exists( 'wp_eMember_install' ) ) {
			add_action( 'asp_subscription_invoice_paid', array( $this, 'handle_recurring_payment_emember' ), 10, 2 );
			add_action( 'asp_subscription_ended', array( $this, 'handle_sub_end_cancel_emember' ), 10, 2 );
			add_action( 'asp_subscription_canceled', array( $this, 'handle_sub_end_cancel_emember' ), 10, 2 );
		}

		add_filter( 'asp_email_body_tags_vals_before_replace', array( $this, 'email_body_tags_vals_before_replace' ), 10, 2 );
		add_filter( 'asp_email_body_after_replace', array( $this, 'email_body_after_replace' ) );
	}

	private function add_ajax_hooks() {
		if ( current_user_can( 'manage_options' ) ) {
			add_action( 'wp_ajax_asp_sub_clear_cache', array( $this, 'ajax_clear_plans_cache' ) );
		}
	}

	public function ajax_clear_plans_cache() {
		$nonce = filter_input( INPUT_POST, 'nonce', FILTER_SANITIZE_STRING );
		if ( ! wp_verify_nonce( $nonce, 'asp-sub-clear-cache' ) ) {
			$ret['success'] = false;
			$ret['msg']     = __( 'Nonce check failed. Please refresh page and try again.', 'asp-sub' );
			wp_send_json( $ret );
		}

		update_option( 'asp_sub_plans_cache', '' );
		$ret['msg'] = __( 'Cache has been cleared.', 'asp-sub' );
		wp_send_json( $ret );
	}

	public static function format_date( $date ) {
		$format   = get_option( 'date_format' ) . ', ' . get_option( 'time_format' );
		$tmp_date = date( 'Y-m-d H:i:s', $date ); //phpcs:ignore
		$ret      = get_date_from_gmt( $tmp_date, $format );
		return $ret;
	}

	public static function get_interval_str( $unit, $count = 0 ) {
		$period_units_str = array(
			'days'   => array( __( 'day', 'asp-sub' ), __( 'days', 'asp-sub' ) ),
			'weeks'  => array( __( 'week', 'asp-sub' ), __( 'weeks', 'asp-sub' ) ),
			'months' => array( __( 'month', 'asp-sub' ), __( 'months', 'asp-sub' ) ),
		);
		if ( ! isset( $period_units_str[ $unit ] ) ) {
			return $unit;
		}
		$ret = $unit;
		if ( $count == 1 ) {
			$ret = $period_units_str[ $unit ][0];
		} else {
			$ret = $period_units_str[ $unit ][1];
		}
		return $ret;
	}

	public static function get_plan_descr( $post_id, $need_total = false ) {
		$variables = get_post_meta( $post_id, 'asp_sub_plan_variables', true );
		$curr      = get_post_meta( $post_id, 'asp_sub_plan_currency', true );
		$price     = get_post_meta( $post_id, 'asp_sub_plan_price', true );
		$price_fmt = AcceptStripePayments::formatted_price( $price, $curr );
		if ( isset( $variables['price'] ) ) {
			$price_fmt = 'N';
		}
		$interval_count = get_post_meta( $post_id, 'asp_sub_plan_period', true );
		$interval       = get_post_meta( $post_id, 'asp_sub_plan_period_units', true );
		$duration       = get_post_meta( $post_id, 'asp_sub_plan_duration', true );
		$trial          = get_post_meta( $post_id, 'asp_sub_plan_trial', true );
		$str            = $price_fmt;
		$interval       = self::get_interval_str( $interval, $interval_count );
		if ( $interval_count == 1 ) {
			$str .= '/' . $interval;
		} else {
			$str .= ' ' . __( 'every', 'asp-sub' ) . ' ' . $interval_count . ' ' . $interval;
		}
		if ( $duration != 0 ) {
			$str .= ' X ' . $duration;
			if ( $need_total && ! isset( $variables['price'] ) ) {
				$str .= '<br />' . __( 'Total:', 'asp-sub' ) . ' ' . AcceptStripePayments::formatted_price( $duration * $price, $curr );
			}
		} else {
			$str .= '<span class="asp_subs_price_until_cancelled"> ' . __( 'until cancelled', 'asp-sub' ) . '</span>';
		}
		if ( $trial ) {
			$trial_interval_str = self::get_interval_str( 'days', $trial );
			// translators: %1$d is number, %2$s is days\weeks\months word
			$str = sprintf( __( 'Free for %1$d %2$s, then', 'asp-sub' ), $trial, $trial_interval_str ) . ' ' . $str;
		}
		return $str;
	}

	public function email_body_tags_vals_before_replace( $tags_vals, $post ) {
		if ( ! isset( $post['txn_id'] ) || substr( $post['txn_id'], 0, 4 ) !== 'sub_' ) {
			//not a subscription
			return $tags_vals;
		}
		$sub_id = $post['txn_id'];
		include_once $this->sub_main->PLUGIN_DIR . 'inc/asp-sub-stripe-subs-class.php';
		$sub_class     = ASPSUB_stripe_subs::get_instance();
		$cancel_url    = $sub_class->get_cancel_link( $sub_id );
		$update_cc_url = $sub_class->get_update_cc_link( $sub_id );
		if ( $cancel_url ) {
			//let's add tags and corresponding vals
			$tags_vals['tags'][] = '{sub_cancel_url}';
			$tags_vals['vals'][] = $cancel_url;
			$tags_vals['tags'][] = '{sub_update_cc_url}';
			$tags_vals['vals'][] = $update_cc_url;
		}

		$curr_plan = ASP_Sub_Plan::get_instance();

		$plan = $curr_plan->get_plan_obj();

		$setup_fee = $curr_plan->get_setup_fee();
		if ( empty( $plan->trial_period_days ) && ! empty( $setup_fee ) ) {

		} else {
			$setup_fee = 0;
		}

		$tags_vals['tags'][] = '{setup_fee_amt}';
		$tags_vals['vals'][] = AcceptStripePayments::formatted_price( $setup_fee, false );

		$trial_setup_fee = $curr_plan->get_trial_setup_fee();
		if ( ! empty( $trial_setup_fee ) && ! empty( $plan->trial_period_days ) ) {

		} else {
			$trial_setup_fee = 0;
		}

		$tags_vals['tags'][] = '{trial_setup_fee_amt}';
		$tags_vals['vals'][] = AcceptStripePayments::formatted_price( $trial_setup_fee, false );

		$post_id = $curr_plan->get_post_id();

		$prod_descr = get_post_meta( $post_id, 'asp_sub_plan_prod_descr', true );

		$tags_vals['tags'][] = '{sub_plan_description}';
		$tags_vals['vals'][] = esc_attr( $prod_descr );

		return $tags_vals;
	}

	public function email_body_after_replace( $body ) {
		//let's remove potential tags leftovers
		$body = preg_replace( array( '/\{sub_cancel_url\}/' ), array( '' ), $body );
		$body = preg_replace( array( '/\{sub_update_cc_url\}/' ), array( '' ), $body );
		return $body;
	}

	public static function is_sub_active( $status ) {
		return in_array( $status, array( 'active', 'trialing', 'incomplete', 'past_due' ), true );
	}

	public static function use_internal_api() {
		if ( method_exists( 'ASP_Utils', 'use_internal_api' )
		&& ASP_Utils::use_internal_api()
		&& version_compare( WP_ASP_PLUGIN_VERSION, self::$min_core_ver_for_internal_api ) >= 0 ) {
			return true;
		}
		return false;
	}

	public function handle_recurring_payment_emember( $sub_post_id, $data ) {
		$ipn_data = array(
			'subscr_id'   => $data['subscription'],
			'payer_email' => $data['customer_email'],
		);

		require_once WP_EMEMBER_PATH . 'ipn/eMember_handle_subsc_ipn_stand_alone.php';

		eMember_update_member_subscription_start_date_if_applicable( $ipn_data );
	}

	public function handle_sub_end_cancel_emember( $sub_post_id, $data ) {
		$ipn_data = array(
			'subscr_id' => $data['id'],
		);

		require_once WP_EMEMBER_PATH . 'ipn/eMember_handle_subsc_ipn_stand_alone.php';

		eMember_handle_subsc_cancel_stand_alone( $ipn_data );
	}

}

ASPSUB_Utils::get_instance();
