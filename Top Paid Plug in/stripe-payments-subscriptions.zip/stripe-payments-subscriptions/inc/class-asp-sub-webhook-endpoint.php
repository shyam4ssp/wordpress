<?php

class ASP_Sub_Webhook_Endpoint {

	private $webhook;
	private $is_internal_api = false;

	public function __construct( $webhook ) {
		$this->webhook = $webhook;
		if ( is_a( $webhook, 'StdClass' ) ) {
			$this->is_internal_api = true;
		}
		return $this;
	}

	public function delete() {
		if ( $this->is_internal_api ) {
			$api = ASP_Stripe_API::get_instance();
			$api->post( 'webhook_endpoints/' . $this->webhook->id, array(), 'DELETE' );
		} else {
			$this->webhook->delete();
		}
	}
}
