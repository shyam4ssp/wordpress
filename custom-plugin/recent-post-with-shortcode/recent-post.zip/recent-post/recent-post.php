<?php
/*
Plugin Name: Get post Using shortcode
Plugin URI: https://axiswebart.com
Description: Get post using shortcode 'recent_post_with_prams' with attribute 'title,cat,limit'
Author: Shyam Pareek
Version: 1.0.0
Author URI: https://axiswebart.com
*/

function recent_post_with_prams($atts = [], $content = null, $tag = ''){
$atts = array_change_key_case((array)$atts, CASE_LOWER);
$r_post = shortcode_atts(['title' => 'Recent post list',], $atts, $tag);
$r_cat = shortcode_atts(['cat' => 'Recent post list',], $atts, $tag);
$r_limit = shortcode_atts(['limit' => 'Recent post list',], $atts, $tag);
$r_post = esc_html__($r_post['title'], 'recent_post_with_prams') ;
$r_cat = esc_html__($r_cat['cat'], 'recent_post_with_prams');
$r_limit = esc_html__($r_limit['limit'], 'recent_post_with_prams');
$args = array(
'numberposts' => $r_limit,
'offset' => 0,
'category' => $r_cat,
'orderby' => 'post_date',
'order' => 'DESC',
'include' => '',
'exclude' => '',
'meta_key' => '',
'meta_value' =>'',
'post_type' => 'post',
'post_status' => 'publish',
'suppress_filters' => true
);

$recent_posts = wp_get_recent_posts( $args, ARRAY_A );
$html='';
$html.='<ul class="recent_with_prams">';
foreach ($recent_posts as $r_posts) {
$html.='<li>'.$r_posts['post_title'].'</li>';
}
$html.='</ul>';
return $html;
}
add_shortcode('recent_post_with_prams','recent_post_with_prams');