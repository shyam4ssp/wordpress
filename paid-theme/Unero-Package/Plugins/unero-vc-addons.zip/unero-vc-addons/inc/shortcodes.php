<?php

/**
 * Define theme shortcodes
 *
 * @package Unero
 */
class Unero_Shortcodes {
	/**
	 * Store variables for js
	 *
	 * @var array
	 */
	public $l10n = array();

	public $maps = array();

	public $api_key = '';

	/**
	 * Check if WooCommerce plugin is actived or not
	 *
	 * @var bool
	 */
	private $wc_actived = false;

	/**
	 * Construction
	 *
	 * @return Mrbara_Shortcodes
	 */
	function __construct() {
		$this->wc_actived = function_exists( 'is_woocommerce' );

		$shortcodes = array(
			'sliders',
			'banner',
			'newsletter',
			'link',
			'products_carousel',
			'about',
			'section_title',
			'posts',
			'banners_grid',
			'banners_carousel',
			'hero_slider',
			'instagram',
			'faqs',
			'cta',
			'icon_box',
			'contact_form',
			'gmap',
			'single_image',
			'video',
			'box_content',
		);

		foreach ( $shortcodes as $shortcode ) {
			add_shortcode( 'unero_' . $shortcode, array( $this, $shortcode ) );
		}

		add_action( 'wp_footer', array( $this, 'footer' ) );
	}


	/**
	 * Load custom js in footer
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function footer() {

		// Load Google maps only when needed
		if ( isset( $this->l10n['map'] ) ) {
			echo '<script>if ( typeof google !== "object" || typeof google.maps !== "object" )
				document.write(\'<script src="//maps.google.com/maps/api/js?sensor=false&key=' . $this->api_key . '"><\/script>\')</script>';
		}

		global $post;
		wp_enqueue_script( 'unero-shortcodes', UNERO_ADDONS_URL . '/assets/js/frontend.js', array( 'jquery' ), '20170418', true );

		$this->l10n['days']      = esc_html__( 'days', 'unero' );
		$this->l10n['hours']     = esc_html__( 'hours', 'unero' );
		$this->l10n['minutes']   = esc_html__( 'minutes', 'unero' );
		$this->l10n['seconds']   = esc_html__( 'seconds', 'unero' );
		$this->l10n['direction'] = is_rtl() ? 'true' : 'false';

		$products_column_mobile = 2;
		if ( function_exists( 'unero_get_option' ) ) {
			$products_column_mobile = intval( unero_get_option( 'product_columns_mobile' ) );
		}

		$this->l10n['product_columns_mobile'] = $products_column_mobile;

		wp_localize_script( 'unero-shortcodes', 'uneroShortCode', $this->l10n );
	}


	/**
	 * Get sliders
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function sliders( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'      => '1',
				'full_width' => '',
				'min_height' => 550,
				'effect'     => 'fade',
				'parallax'   => '',
				'auto_play'  => '',
				'sliders'    => '',
				'el_class'   => '',
			), $atts
		);

		if ( ! $atts['sliders'] ) {
			return '';
		}

		$css_class = $atts['el_class'];

		$sliders = (array) json_decode( urldecode( $atts['sliders'] ), true );

		$output = array();
		foreach ( $sliders as $slider ) {
			$image_src = '';
			if ( isset( $slider['image'] ) && $slider['image'] ) {
				$image = wp_get_attachment_image_src( $slider['image'], 'full' );

				if ( $image ) {
					$image_src = sprintf( '<div class="featured-img" style="background-image: url(%s)"></div>', esc_url( $image[0] ) );
				}
			}
			$link = '';
			if ( isset( $slider['link'] ) && $slider['link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $slider['link'] ) );
				}
			}
			if ( isset( $slider['link_type'] ) && $slider['link_type'] ) {
				if ( ! empty( $link ) ) {
					$image_src .= sprintf(
						'<a href="%s" class="link-slider" %s%s></a>',
						esc_url( $link['url'] ),
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : ''
					);
				}
			}

			if ( isset( $slider['video_url'] ) && $slider['video_url'] ) {
				$video_url = $slider['video_url'];
				$ext       = wp_check_filetype( $video_url );
				$image_src .= sprintf(
					'<div class="unvideo-bg">' .
					'<video height="%s" loop muted autoplay>' .
					'<source src="%s" type="%s">' .
					'</video>' .
					'</div>',
					esc_attr( intval( $atts['min_height'] ) ),
					esc_url( $video_url ),
					esc_attr( $ext['type'] )
				);
			}

			$content = '';
			if ( isset( $slider['title'] ) && $slider['title'] ) {

				$title_style = '';
				if ( isset( $slider['title_color'] ) && $slider['title_color'] ) {
					$title_style = 'style=color:' . $slider['title_color'] . '';
				}
				$content = sprintf( '<div class="title" %s>%s</div>', $title_style, $slider['title'] );
			}

			if ( ! empty( $link ) ) {
				$link_style = '';
				if ( isset( $slider['link_color'] ) && $slider['link_color'] ) {
					$link_style = 'style=color:' . $slider['link_color'] . '';
				}
				$content .= sprintf(
					'<a href="%s" class="link" %s%s %s>%s</a>',
					esc_url( $link['url'] ),
					! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
					! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
					$link_style,
					esc_html( $link['title'] )
				);
			}

			$item_class = '';

			if ( isset( $slider['text_align'] ) && $slider['text_align'] ) {
				$item_class = 'text-' . $slider['text_align'];
			}

			$output[] = sprintf(
				'<li>' .
				'%s' .
				'<div class="cs-content %s">' .
				'<div class="container">' .
				'<div class="cs-layer">' .
				'%s' .
				'</div>' .
				'</div>' .
				'</div>' .
				'</li>',
				$image_src,
				esc_attr( $item_class ),
				$content
			);
		}


		$speed    = '500';
		$auto     = 0;
		$autoplay = intval( $atts['auto_play'] );

		if ( $autoplay ) {
			$speed = $autoplay;
			$auto  = 1;
		}

		$parallax = 0;
		if ( $atts['parallax'] && $atts['effect'] == 'fade' ) {
			$parallax  = 1;
			$css_class .= ' parallax';
		}

		$height                            = intval( $atts['min_height'] );
		$id                                = uniqid( 'unero-sliders-' );
		$this->l10n['uneroSliders'][ $id ] = array(
			'autoplay'   => $auto,
			'speed'      => $speed,
			'transition' => $atts['effect'],
			'height'     => $height,
			'parallax'   => $parallax,
		);

		$css_class .= ' style-' . esc_attr( $atts['style'] );
		if ( $atts['full_width'] ) {
			$css_class .= ' full-width';
		}

		if ( function_exists( 'unero_get_option' ) ) {
			if ( intval( unero_get_option( 'preloader' ) ) ) {
				$css_class .= ' no-preloader';
			}
		}

		return sprintf(
			'<div class="unero-sliders %s">' .
			'<ul id="%s">' .
			'%s' .
			'</ul>' .
			'</div>',
			esc_attr( $css_class ),
			esc_attr( $id ),
			implode( ' ', $output )
		);
	}

	/**
	 * Get banners grid
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function banners_grid( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'banners'  => '',
				'el_class' => '',
			), $atts
		);

		if ( ! $atts['banners'] ) {
			return '';
		}

		$css_class = $atts['el_class'];

		$banners = (array) json_decode( urldecode( $atts['banners'] ), true );

		$output = array();
		$i      = 0;
		foreach ( $banners as $banner ) {
			$item_class = 'banner-item-normal';
			$image_size = 'unero-product-cat-normal';

			if ( $i % 4 == 0 || $i % 4 == 3 ) {
				$image_size = 'unero-product-cat-long';
				$item_class = 'banner-item-long';
			}

			$i ++;

			$content = '';
			if ( isset( $banner['title'] ) && $banner['title'] ) {
				$title_style = '';
				if ( isset( $banner['title_color'] ) && $banner['title_color'] ) {
					$title_style = 'style=color:' . $banner['title_color'] . '';
				}
				$content = sprintf( '<h3 %s>%s</h3>', $title_style, $banner['title'] );
			}

			$link_all = '';
			if ( isset( $banner['link'] ) && $banner['link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $banner['link'] ) );
					if ( ! empty( $link ) ) {
						$link_style = '';
						if ( isset( $banner['link_color'] ) && $banner['link_color'] ) {
							$link_style = 'style=color:' . $banner['link_color'] . '';
						}
						$content .= sprintf(
							'<a href="%s" class="link" %s%s %s>%s</a>',
							esc_url( $link['url'] ),
							! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
							! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
							$link_style,
							esc_html( $link['title'] )
						);

						if ( isset( $banner['link_image'] ) && $banner['link_image'] ) {
							$link_all = sprintf(
								'<a href="%s" class="link-all" %s%s></a>',
								esc_url( $link['url'] ),
								! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
								! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : ''
							);
						}
					}
				}
			}

			$content = sprintf( '<div class="banner-item-text">%s</div>', $content );
			if ( isset( $banner['image'] ) && $banner['image'] ) {
				$content .= wp_get_attachment_image( $banner['image'], $image_size );

			}

			$content .= $link_all;

			$output[] = sprintf( '<li class="banner-item %s">%s</li>', esc_attr( $item_class ), $content );
		}


		return sprintf(
			'<div class="unero-banners-grid %s">' .
			'<ul>' .
			'%s' .
			'</ul>' .
			'</div>',
			esc_attr( $css_class ),
			implode( ' ', $output )
		);
	}

	/**
	 * Get banners_carousel
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function banners_carousel( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'auto_play' => '',
				'banners'   => '',
				'number'    => '3',
				'el_class'  => '',
			), $atts
		);

		if ( ! $atts['banners'] ) {
			return '';
		}

		$banners = (array) json_decode( urldecode( $atts['banners'] ), true );

		$output = array();
		foreach ( $banners as $banner ) {
			$image_src = '';
			if ( isset( $banner['image'] ) && $banner['image'] ) {
				$image_src = wp_get_attachment_image( $banner['image'], 'full' );
			}

			$link = '';
			if ( isset( $banner['link'] ) && $banner['link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $banner['link'] ) );
				}
			}

			if ( isset( $banner['link_type'] ) && $banner['link_type'] ) {
				if ( ! empty( $link ) ) {
					$image_src .= sprintf(
						'<a href="%s" class="link-all" %s%s></a>',
						esc_url( $link['url'] ),
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : ''
					);
				}
			}

			$content = '';
			if ( isset( $banner['title'] ) && $banner['title'] ) {
				$content = sprintf( '<div class="title">%s</div>', $banner['title'] );
			}

			if ( ! empty( $link ) ) {
				$content .= sprintf(
					'<a href="%s" class="link" %s%s>%s</a>',
					esc_url( $link['url'] ),
					! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
					! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
					esc_html( $link['title'] )
				);
			}

			$output[] = sprintf(
				'<li>' .
				'%s' .
				'<div class="cs-content">' .
				'<div class="cs-layer">' .
				'%s' .
				'</div>' .
				'</div>' .
				'</li>',
				$image_src,
				$content
			);
		}


		$speed    = '500';
		$auto     = 0;
		$autoplay = intval( $atts['auto_play'] );

		if ( $autoplay ) {
			$speed = $autoplay;
			$auto  = 1;
		}

		$id                                   = uniqid( 'banners-carousel-' );
		$this->l10n['bannersCarousel'][ $id ] = array(
			'autoplay' => $auto,
			'number'   => intval( $atts['number'] ),
			'speed'    => $speed,
		);

		$css_class = $atts['el_class'];

		return sprintf(
			'<div class="unero-banners-carousel %s">' .
			'<ul id="%s">' .
			'%s' .
			'</ul>' .
			'</div>',
			esc_attr( $css_class ),
			esc_attr( $id ),
			implode( ' ', $output )
		);
	}

	/**
	 * Get banner
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function banner( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'image'             => '',
				'title'             => '',
				'subtitle'          => '',
				'subtitle_align'    => 'left',
				'subtitle_position' => 'top',
				'link'              => '',
				'el_class'          => '',
			), $atts
		);

		$output = array();

		$css_class[] = $atts['el_class'];

		$link_html = '';
		if ( $atts['link'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['link'] ) );
				if ( ! empty( $link ) ) {
					$link_html = sprintf(
						'<a href="%s" class="link" %s%s>',
						esc_url( $link['url'] ),
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : ''
					);
				}
			}
		}

		$image_html = '';
		if ( $atts['image'] ) {
			if ( function_exists( 'unero_get_image_html' ) ) {
				$image_html = unero_get_image_html( $atts['image'], 'full' );

			} else {
				$image_html = wp_get_attachment_image( $atts['image'], 'full' );
			}
		}

		if ( $atts['title'] ) {
			$image_html .= sprintf( '<h2>%s</h2>', $atts['title'] );
		}

		if ( $link_html ) {
			$output[] = sprintf(
				'%s %s' .
				'</a>',
				$link_html,
				$image_html
			);
		} else {
			$output[] = $image_html;
		}


		if ( $atts['subtitle'] ) {
			$output[] = sprintf( '<span class="text"> <span class="subtitle">%s</span></span>', $atts['subtitle'] );
		}

		$css_class[] = 'text-align-' . $atts['subtitle_align'];
		$css_class[] = 'text-position-' . $atts['subtitle_position'];

		return sprintf(
			'<div class="unero-banner %s">' .
			'<div class="banner-content">' .
			'%s' .
			'</div>' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )
		);

	}

	/**
	 * Get tabs slider
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function hero_slider( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'full_width' => '',
				'layout'     => 'tabs',
				'sliders'    => '',
				'el_class'   => '',
			), $atts
		);

		if ( ! $atts['sliders'] ) {
			return '';
		}

		$sliders = (array) json_decode( urldecode( $atts['sliders'] ), true );

		$output = array();
		$images = array();
		$i      = 0;
		foreach ( $sliders as $slider ) {
			$first_class = '';
			if ( $i == 0 ) {
				$first_class = 'active';
			}
			$i ++;

			if ( isset( $slider['image'] ) && $slider['image'] ) {
				$props = wp_get_attachment_image_src( $slider['image'], 'full' );
				if ( $props ) {
					$images[] = sprintf( '<div class="item-image %s" style="background-image:url(%s)"></div>', esc_attr( $first_class ), esc_url( $props[0] ) );
				}
			}

			$item_content = '';
			if ( isset( $slider['title'] ) && $slider['title'] ) {
				$item_content .= sprintf( '<h2 class="title">%s</h2>', wp_kses( $slider['title'], wp_kses_allowed_html( 'post' ) ) );
			}

			if ( isset( $slider['desc'] ) && $slider['desc'] ) {
				$item_content .= sprintf( '<span class="desc">%s</span>', wp_kses( $slider['desc'], wp_kses_allowed_html( 'post' ) ) );
			}


			if ( isset( $slider['link'] ) && $slider['link'] ) {
				if ( function_exists( 'vc_build_link' ) ) {
					$link = array_filter( vc_build_link( $slider['link'] ) );
					if ( ! empty( $link ) ) {
						$item_content = sprintf(
							'<a href="%s" class="item-inner" %s%s>%s</a>',
							esc_url( $link['url'] ),
							! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
							! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
							$item_content
						);
					}
				}
			}

			$output[] = sprintf( '<div class="item-content %s">%s</div>', esc_attr( $first_class ), $item_content );
		}


		$css_class = $atts['el_class'];
		if ( $atts['full_width'] ) {
			$css_class .= ' full-width';
		}

		$items_class = 'slider-tabs-content';
		if ( $atts['layout'] == 'grid' ) {
			$items_class = 'slider-grid-content';
		}

		$css_class .= ' hero-slider-' . $atts['layout'];

		return sprintf(
			'<div class="unero-hero-slider %s">' .
			'<div class="hero-slider-content">' .
			'<div class="%s">' .
			'<div class="slider-items-content">' .
			'%s' .
			'</div>' .
			'</div>' .
			'<div class="slider-images-content">' .
			'%s' .
			'</div>' .
			'</div>' .
			'</div>',
			esc_attr( $css_class ),
			esc_attr( $items_class ),
			implode( ' ', $output ),
			implode( ' ', $images )
		);
	}

	/**
	 * Get newsletter
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function newsletter( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'    => '1',
				'desc'     => '',
				'form'     => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];
		$css_class[] = 'style-' . $atts['style'];

		if ( $content ) {
			$content = sprintf( '<div class="nl-title">%s</div>', $content );
		}

		if ( $atts['desc'] ) {
			$content .= sprintf( '<div class="nl-desc">%s</div>', $atts['desc'] );
		}

		$form_html = '';
		if ( $atts['form'] ) {
			$form_html = sprintf( '<div class="nl-form">%s</div>', do_shortcode( '[mc4wp_form id="' . esc_attr( $atts['form'] ) . '"]' ) );
		}

		$col_left  = 'col-md-12 col-sm-12 col-xs-12 col-content';
		$col_right = 'col-md-12 col-sm-12 col-xs-12';

		if ( $atts['style'] == '2' ) {
			$col_left  = 'col-md-5 col-sm-12 col-xs-12 col-content';
			$col_right = 'col-md-7 col-sm-12 col-xs-12';
		}


		return sprintf(
			'<div class="unero-newsletter %s">' .
			'<div class="row">' .
			'<div class="%s">' .
			'%s' .
			'</div>' .
			'<div class="%s">' .
			'%s' .
			'</div>' .
			'</div>' .
			'</div>',
			implode( ' ', $css_class ),
			esc_attr( $col_left ),
			$content,
			esc_attr( $col_right ),
			$form_html
		);

	}

	/**
	 * Get newsletter
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function link( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'link'     => '',
				'el_class' => '',
			), $atts
		);


		$css_class[] = $atts['el_class'];

		$link_html = '';
		if ( $atts['link'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['link'] ) );
				if ( ! empty( $link ) ) {
					$link_html = sprintf(
						'<a href="%s" class="link" %s%s>%s</a>',
						esc_url( $link['url'] ),
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						$content
					);
				}
			}
		}

		return sprintf(
			'<div class="unero-link %s">' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			$link_html
		);

	}

	/**
	 * Get newsletter
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function about( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'    => '',
				'link'     => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$output = array();

		if ( $atts['title'] ) {
			$output[] = sprintf( '<div class="title">%s</div>', $atts['title'] );
		}

		if ( $content ) {
			$output[] = sprintf( '<div class="desc">%s</div>', $content );
		}

		if ( $atts['link'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['link'] ) );
				if ( ! empty( $link ) ) {
					$output[] = sprintf(
						'<div class="link"><a href="%s" %s%s>%s</a></div>',
						esc_url( $link['url'] ),
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						$link['title']
					);
				}
			}
		}


		return sprintf(
			'<div class="unero-about %s">' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )

		);

	}

	/**
	 * Get Section Title
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function section_title( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'    => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$output = array();

		if ( $atts['title'] ) {
			$output[] = sprintf( '<h2 class="title">%s</h2>', $atts['title'] );
		}

		if ( $content ) {
			$output[] = sprintf( '<div class="desc">%s</div>', $content );
		}


		return sprintf(
			'<div class="unero-section-title %s">' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			implode( ' ', $output )

		);

	}

	/**
	 * Products shortcode
	 *
	 * @param array $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function products_carousel( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'      => '1',
				'title'      => '',
				'products'   => 'recent',
				'categories' => '',
				'per_page'   => 12,
				'number'     => 4,
				'orderby'    => '',
				'order'      => '',
				'link'       => '',
				'autoplay'   => 0,
				'el_class'   => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];
		$style       = intval( $atts['style'] );

		if ( $style != 1 ) {
			$css_class[] = 'style-' . $style;
		}

		$output = array();

		$autoplay = false;
		$speed    = 1000;

		if ( intval( $atts['autoplay'] ) ) {
			$autoplay = true;
			$speed    = intval( $atts['autoplay'] );
		}

		$output[] = sprintf( '<h2 class="title">%s</h2>', $atts['title'] );

		$params = sprintf(
			'per_page="%s" ' .
			'columns = "%s" ' .
			'category = "%s" ' .
			'orderby = "%s" ' .
			'order = "%s" ',
			$atts['per_page'],
			$atts['number'],
			$atts['categories'],
			$atts['orderby'],
			$atts['order']
		);

		switch ( $atts['products'] ) {
			case 'featured':
				$output[] = do_shortcode( '[featured_products ' . $params . ']' );
				break;
			case 'best_selling':
				$output[] = do_shortcode( '[best_selling_products ' . $params . ']' );
				break;
			case 'top_rated':
				$output[] = do_shortcode( '[top_rated_products ' . $params . ']' );
				break;
			case 'sale':
				$output[] = do_shortcode( '[sale_products ' . $params . ']' );
				break;
			default:
				$output[] = do_shortcode( '[recent_products ' . $params . ']' );
		}


		$id                                    = uniqid( 'products-carousel-' );
		$this->l10n['productsCarousel'][ $id ] = array(
			'autoplay' => $autoplay,
			'speed'    => $speed,
			'columns'  => intval( $atts['number'] ),
		);

		if ( function_exists( 'vc_build_link' ) ) {
			$link = array_filter( vc_build_link( $atts['link'] ) );
			if ( ! empty( $link ) ) {
				$output[] = sprintf(
					'<div class="footer-link"><a href="%s" class="link" %s%s>%s</a></div>',
					esc_url( $link['url'] ),
					! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
					! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
					esc_html( $link['title'] )
				);
			}
		}

		return sprintf(
			'<div class="unero-products-carousel %s" id="%s">%s</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_attr( $id ),
			implode( '', $output )
		);
	}

	/**
	 * posts
	 *
	 * @param array $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function posts( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'          => '',
				'categories'     => '',
				'per_page'       => 3,
				'excerpt_length' => 15,
				'orderby'        => '',
				'order'          => '',
				'el_class'       => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$output = array();

		$output[] = sprintf( '<div class="unero-section-title"><h2>%s</h2></div>', $atts['title'] );

		$query_args = array(
			'posts_per_page'      => intval( $atts['per_page'] ),
			'post_type'           => 'post',
			'ignore_sticky_posts' => true,
			'orderby'             => $atts['orderby'],
			'order'               => $atts['order']
		);

		if ( ! empty( $atts['categories'] ) ) {
			$query_args['category_name'] = $atts['categories'];
		}
		$query = new WP_Query( $query_args );

		while ( $query->have_posts() ) : $query->the_post();
			$time_string   = '<time class="e-date" datetime="%1$s">%2$s</time>';
			$time_string   = sprintf(
				$time_string,
				esc_attr( get_the_date( 'c' ) ),
				esc_html( get_the_date() )
			);
			$archive_year  = get_the_time( 'Y' );
			$archive_month = get_the_time( 'm' );
			$archive_day   = get_the_time( 'd' );

			$image_html = '';
			if ( function_exists( 'unero_get_image_html' ) ) {
				$image_html = unero_get_image_html( get_post_thumbnail_id(), 'unero-product-masonry-normal' );

			} else {
				$image_html = wp_get_attachment_image( get_post_thumbnail_id(), 'unero-product-masonry-normal' );

			}

			$output[] = sprintf(
				'<div class="col-md-4 col-sm-4 col-xs-12">' .
				'<div class="post-item ">' .
				'%s' .
				'<div class="post-item-content">' .
				'<div class="post-content">' .
				'<a href="%s" class="entry-date">%s</a>' .
				'<h2><a href="%s" class="post-title">%s</a></h2>' .
				'</div>' .
				'<div class="post-footer">' .
				'<div class="desc">%s</div>' .
				'<a href="%s" class="post-link">%s</a>' .
				'</div>' .
				'</div>' .
				'</div>' .
				'</div>',
				$image_html,
				esc_url( get_day_link( $archive_year, $archive_month, $archive_day ) ),
				$time_string,
				esc_url( get_the_permalink() ),
				get_the_title(),
				$this->unero_sc_content_limit( get_the_excerpt(), intval( $atts['excerpt_length'] ), false, false ),
				esc_url( get_the_permalink() ), esc_html__( 'Continue', 'unero' )
			);
		endwhile;
		wp_reset_postdata();

		return sprintf(
			'<div class="unero-posts %s">' .
			'<div class="row">' .
			'%s' .
			'</div>' .
			'</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * Get Instagram
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function instagram( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'access_token' => '',
				'title'        => '',
				'numbers'      => 6,
				'image_size'   => 'low_resolution',
				'columns'      => '5',
				'hashtag'      => '',
				'autoplay'     => '',
				'no_space'     => '',
				'el_class'     => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['no_space'] ) {
			$css_class[] = 'no-space';
		}

		if ( ! function_exists( 'unero_instagram_photos' ) ) {
			return '';
		}

		$output = unero_instagram_photos( $atts['hashtag'], intval( $atts['numbers'] ), $atts['title'], intval( $atts['columns'] ), intval( $atts['autoplay'] ), $atts['access_token'], $atts['image_size'] );

		return sprintf(
			'<div class="unero-instagram %s">' .
			'<div class="instagram-content">' .
			'%s' .
			'</div>' .
			'</div>',
			implode( ' ', $css_class ),
			$output
		);

	}

	/**
	 * Video banner shortcode
	 *
	 * @since  1.0
	 *
	 * @param  array $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function video( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'banner_type' => '',
				'video'       => '',
				'image'       => '',
				'mute'        => '',
				'subtitle'    => '',
				'title'       => '',
				'height'      => 'auto',
				'link'        => '',
				'el_class'    => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$output = array();

		if ( $atts['subtitle'] ) {
			$output[] = sprintf( '<div class="v-subtitle">%s</div>', $atts['subtitle'] );
		}

		if ( $atts['title'] ) {
			$output[] = sprintf( '<div class="v-title">%s</div>', $atts['title'] );
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );

			}

			$output[] = sprintf( '<div class="v-desc">%s</div>', $content );
		}

		if ( $atts['link'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['link'] ) );
				if ( ! empty( $link ) ) {
					$output[] = sprintf(
						'<a href="%s" class="link" %s%s>%s</a>',
						esc_url( $link['url'] ),
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						$link['title']
					);
				}
			}
		}
		$image = wp_get_attachment_image_src( intval( $atts['image'] ), 'full' );

		if ( empty( $atts['video'] ) ) {

			if ( $image ) {
				return sprintf(
					'<div class="un-video-banner show-only-image %s" style="height: %s">
						<div class="featured-image" style="background-image: url(%s)"></div>
						<div class="banner-content">
							%s
						</div>
					</div>',
					esc_attr( implode( ' ', $css_class ) ),
					esc_attr( $atts['height'] ),
					esc_url( $image[0] ),
					implode( ' ', $output )

				);
			}

		} else {
			$ext = wp_check_filetype( $atts['video'] );

			return sprintf(
				'<div class="un-video-banner %s">
				<video height="%s" preload="none" poster="%s" loop autoplay %s>
					<source src="%s" type="%s">
				</video>
				<div class="banner-content">
					%s
                </div>
			</div>',
				esc_attr( implode( ' ', $css_class ) ),
				esc_attr( $atts['height'] ),
				esc_url( $image[0] ),
				! empty( $atts['mute'] ) ? 'muted' : '',
				esc_url( $atts['video'] ),
				esc_attr( $ext['type'] ),
				implode( ' ', $output )

			);
		}


	}

	/**
	 * Video banner shortcode
	 *
	 * @since  1.0
	 *
	 * @param  array $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function box_content( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'subtitle' => '',
				'title'    => '',
				'link'     => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$output = array();

		if ( $atts['subtitle'] ) {
			$output[] = sprintf( '<div class="b-subtitle">%s</div>', $atts['subtitle'] );
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}

			$output[] = sprintf( '<div class="b-title">%s</div>', $content );
		}

		if ( $atts['link'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['link'] ) );
				if ( ! empty( $link ) ) {
					$output[] = sprintf(
						'<a href="%s" class="link" %s%s>%s</a>',
						esc_url( $link['url'] ),
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						$link['title']
					);
				}
			}
		}

		return sprintf(
			'<div class="un-box-content %s">
				<div class="b-content">
					%s
                </div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( ' ', $output )

		);
	}

	/**
	 * Get FAQs
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function faqs( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'    => '',
				'faqs'     => '',
				'el_class' => '',
			), $atts
		);

		if ( ! $atts['faqs'] ) {
			return '';
		}

		$faqs = (array) json_decode( urldecode( $atts['faqs'] ), true );

		$output = array();

		$output[] = sprintf( '<div class="col-gtitle col-md-3 col-sm-3 col-xs-12"><h2 class="g-title">%s</h2></div>', $atts['title'] );

		$output[] = '<div class="col-md-9 col-sm-9 col-xs-12">';
		$output[] = '<div class="row">';
		foreach ( $faqs as $faq ) {
			$output[] = '<div class="faq-item">';

			if ( isset( $faq['title'] ) && $faq['title'] ) {
				$output[] = sprintf( '<div class="col-title col-md-5 col-sm-5 col-xs-12"> <h3 class="title">%s</h3></div>', $faq['title'] );
			}

			if ( isset( $faq['desc'] ) && $faq['desc'] ) {
				$output[] = sprintf( '<div class="col-md-7 col-sm-7 col-xs-12"> <div class="desc">%s</div></div>', $faq['desc'] );
			}

			$output[] = '</div>';
		}

		$output[] = '</div>';
		$output[] = '</div>';

		return sprintf(
			'<div class="unero-faq_group">' .
			'<div class="row">' .
			'%s' .
			'</div>' .
			'</div>',
			implode( ' ', $output )
		);
	}

	/**
	 * Get cta
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function cta( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'link'     => '',
				'el_class' => '',
			), $atts
		);


		$css_class[] = $atts['el_class'];

		$link_html = $content;
		if ( $atts['link'] ) {
			if ( function_exists( 'vc_build_link' ) ) {
				$link = array_filter( vc_build_link( $atts['link'] ) );
				if ( ! empty( $link ) ) {
					$link_html .= sprintf(
						'<a href="%s" class="link" %s%s>%s</a>',
						esc_url( $link['url'] ),
						! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
						! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
						$link['title']
					);
				}
			}
		}

		return sprintf(
			'<div class="unero-cta %s">' .
			'%s' .
			'</div>',
			implode( ' ', $css_class ),
			$link_html
		);

	}

	/**
	 * Map shortcode
	 *
	 * @since 1.0.0
	 * Display icon box 1 shortcode
	 *
	 * @param array $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function icon_box( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'    => '',
				'icon'     => '',
				'el_class' => '',
			), $atts
		);

		$output = array();


		if ( $atts['icon'] ) {
			$output[] = sprintf( '<div class="b-icon"><span class="%s"></span></div>', $atts['icon'] );
		}

		if ( $atts['title'] ) {
			$output[] = sprintf( '<div class="b-title">%s</div>', $atts['title'] );
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = sprintf( '<div class="b-content">%s</div>', $content );
		}


		return sprintf(
			'<div class="unero-icon-box %s">
				%s
			</div>',
			esc_attr( $atts['el_class'] ),
			implode( '', $output )
		);
	}

	/**
	 * Shortcode to display contact form
	 *
	 * @param  array $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function contact_form( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'form'     => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		return sprintf(
			'<div class="unero-contact-form %s">
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			do_shortcode( '[contact-form-7 id="' . esc_attr( $atts['form'] ) . '"]' )
		);
	}

	/**
	 * Shortcode to display single image
	 *
	 * @param  array $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function single_image( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'image'      => '',
				'image_size' => 'full',
				'el_class'   => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$image_id = intval( $atts['image'] );
		if ( ! $atts['image'] ) {
			return;
		}

		$image_full = wp_get_attachment_image_src( $atts['image'], 'full' );

		if ( ! $image_full ) {
			return;
		}

		$image_size = $atts['image_size'];
		$image_src  = '';
		if ( function_exists( 'wpb_getImageBySize' ) ) {
			$image = wpb_getImageBySize(
				array(
					'attach_id'  => $image_id,
					'thumb_size' => $image_size,
				)
			);

			if ( $image['thumbnail'] ) {
				$image_src = $image['thumbnail'];
			} elseif ( $image['p_img_large'] ) {
				$image_src = sprintf( '<img src="%s">', esc_url( $image['p_img_large'][0] ) );
			}

		}

		if ( empty( $image_src ) ) {
			$image_src = wp_get_attachment_image( $image_id, $image_size );
		}

		return sprintf(
			'<div class="unero-single-image %s">' .
			'<a href="%s" class="photoswipe" data-width="%s" data-height="%s">' .
			'%s' .
			'</a>' .
			'</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_url( $image_full[0] ),
			esc_attr( $image_full[1] ),
			esc_attr( $image_full[2] ),
			$image_src
		);
	}

	/**
	 * Map shortcode
	 *
	 * @since 1.0.0
	 *
	 * @param array $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function gmap( $atts, $content ) {
		$atts  = shortcode_atts(
			array(
				'api_key' => '',
				'marker'  => '',
				'address' => '',
				'width'   => '',
				'height'  => '450',
				'zoom'    => '13',
				'css'     => '',
			), $atts
		);
		$class = array(
			'unero-map-shortcode',
			$atts['css'],
		);

		$style = '';
		if ( $atts['width'] ) {
			$unit = 'px';
			if ( strpos( $atts['width'], '%' ) ) {
				$unit = '%;';
			}

			$atts['width'] = intval( $atts['width'] );
			$style         .= 'width: ' . $atts['width'] . $unit . ';';
		}
		if ( $atts['height'] ) {
			$unit = 'px';
			if ( strpos( $atts['height'], '%' ) ) {
				$unit = '%;';
			}

			$atts['height'] = intval( $atts['height'] );
			$style          .= 'height: ' . $atts['height'] . $unit . ';';
		}
		if ( $atts['zoom'] ) {
			$atts['zoom'] = intval( $atts['zoom'] );
		}

		$id   = uniqid( 'unero_map_' );
		$html = sprintf(
			'<div class="%s"><div id="%s" class="ta-map" style="%s"></div></div>',
			implode( ' ', $class ),
			$id,
			$style
		);

		$coordinates = $this->get_coordinates( $atts['address'], $atts['api_key'] );

		if ( isset( $coordinates['error'] ) ) {
			return $coordinates['error'];
		}
		$marker = '';
		if ( $atts['marker'] ) {
			if ( filter_var( $atts['marker'], FILTER_VALIDATE_URL ) ) {
				$marker = $atts['marker'];
			} else {
				$attachment_image = wp_get_attachment_image_src( intval( $atts['marker'] ), 'full' );
				$marker           = $attachment_image ? $attachment_image[0] : '';
			}
		}

		$this->api_key = $atts['api_key'];

		$this->l10n['map'][ $id ] = array(
			'type'    => 'normal',
			'lat'     => $coordinates['lat'],
			'lng'     => $coordinates['lng'],
			'address' => $atts['address'],
			'zoom'    => $atts['zoom'],
			'marker'  => $marker,
			'height'  => $atts['height'],
			'info'    => $content,
		);

		return $html;
	}

	// Get template part

	/**
	 * Helper function to get coordinates for map
	 *
	 * @since 1.0.0
	 *
	 * @param string $address
	 * @param bool $refresh
	 *
	 * @return array
	 */
	function get_coordinates( $address, $api_key, $refresh = false ) {
		$address_hash = md5( $address );
		$coordinates  = get_transient( $address_hash );
		$results      = array( 'lat' => '', 'lng' => '' );

		if ( $refresh || $coordinates === false ) {
			$args     = array( 'address' => urlencode( $address ), 'sensor' => 'false', 'key' => $api_key );
			$url      = add_query_arg( $args, 'https://maps.googleapis.com/maps/api/geocode/json' );
			$response = wp_remote_get( $url );

			if ( is_wp_error( $response ) ) {
				$results['error'] = esc_html__( 'Can not connect to Google Maps APIs', 'unero' );

				return $results;
			}

			$data = wp_remote_retrieve_body( $response );

			if ( is_wp_error( $data ) ) {
				$results['error'] = esc_html__( 'Can not connect to Google Maps APIs', 'unero' );

				return $results;
			}

			if ( $response['response']['code'] == 200 ) {
				$data = json_decode( $data );

				if ( $data->status === 'OK' ) {
					$coordinates = $data->results[0]->geometry->location;

					$results['lat']     = $coordinates->lat;
					$results['lng']     = $coordinates->lng;
					$results['address'] = (string) $data->results[0]->formatted_address;

					// cache coordinates for 3 months
					set_transient( $address_hash, $results, 3600 * 24 * 30 * 3 );
				} elseif ( $data->status === 'ZERO_RESULTS' ) {
					$results['error'] = esc_html__( 'No location found for the entered address.', 'unero' );
				} elseif ( $data->status === 'INVALID_REQUEST' ) {
					$results['error'] = esc_html__( 'Invalid request. Did you enter an address?', 'unero' );
				} else {
					$results['error'] = esc_html__( 'Something went wrong while retrieving your map, please ensure you have entered the short code correctly.', 'unero' );
				}
			} else {
				$results['error'] = esc_html__( 'Unable to contact Google API service.', 'unero' );
			}
		} else {
			$results = $coordinates; // return cached results
		}

		return $results;
	}


	/**
	 * Get or display limited words from given string.
	 * Strips all tags and shortcodes from string.
	 *
	 * @since 1.0.0
	 *
	 * @param integer $num_words The maximum number of words
	 * @param string $more More link.
	 * @param bool $echo Echo or return output
	 *
	 * @return string|void Limited content.
	 */
	function unero_sc_content_limit( $content, $num_words, $more = "&hellip;", $echo = true ) {

		// Strip tags and shortcodes so the content truncation count is done correctly
		$content = strip_tags( strip_shortcodes( $content ), apply_filters( 'unero_content_limit_allowed_tags', '<script>,<style>' ) );

		// Remove inline styles / scripts
		$content = trim( preg_replace( '#<(s(cript|tyle)).*?</\1>#si', '', $content ) );

		// Truncate $content to $max_char
		$content = wp_trim_words( $content, $num_words );

		if ( $more ) {
			$output = sprintf(
				'<p>%s <a href="%s" class="more-link" title="%s">%s</a></p>',
				$content,
				get_permalink(),
				sprintf( esc_html__( 'Continue reading &quot;%s&quot;', 'unero' ), the_title_attribute( 'echo=0' ) ),
				esc_html( $more )
			);
		} else {
			$output = sprintf( '<p>%s</p>', $content );
		}

		if ( ! $echo ) {
			return $output;
		}

		echo $output;
	}


}

