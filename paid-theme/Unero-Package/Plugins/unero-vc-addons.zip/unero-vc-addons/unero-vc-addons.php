<?php
/**
 * Plugin Name: Unero WPBakery Page Builder Addons
 * Plugin URI: http://drfuri.com/unero
 * Description: Extra elements for WPBakery Page Builder. It was built for Unero theme.
 * Version: 1.1.5
 * Author: DrFuri
 * Author URI: http://drfuri.com/
 * License: GPL2+
 * Text Domain: unero
 * Domain Path: /lang/
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if ( ! defined( 'UNERO_ADDONS_DIR' ) ) {
	define( 'UNERO_ADDONS_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'UNERO_ADDONS_URL' ) ) {
	define( 'UNERO_ADDONS_URL', plugin_dir_url( __FILE__ ) );
}

require_once UNERO_ADDONS_DIR . '/inc/visual-composer.php';
require_once UNERO_ADDONS_DIR . '/inc/shortcodes.php';
require_once UNERO_ADDONS_DIR . '/inc/widgets/widgets.php';

if ( is_admin() ) {
	require_once UNERO_ADDONS_DIR . '/inc/importer.php';
}

/**
 * Init
 */
function unero_vc_addons_init() {
	load_plugin_textdomain( 'unero', false, dirname( plugin_basename( __FILE__ ) ) . '/lang' );

	new Unero_VC;
	new Unero_Shortcodes;

}

add_action( 'after_setup_theme', 'unero_vc_addons_init', 20 );

