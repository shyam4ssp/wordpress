<?php
/**
 * Template Name: AC Tune-Up 714
 *
 * @package Tisson
 * @author Muffin Group
 */
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->

<!-- head -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>
<?php
global $post;
if( mfn_opts_get('mfn-seo') && is_object($post) && get_post_meta( get_the_ID(), 'mfn-meta-seo-title', true ) ){
	echo stripslashes( get_post_meta( get_the_ID(), 'mfn-meta-seo-title', true ) );
} else {
	global $page, $paged;
	wp_title( '|', true, 'right' );
	bloginfo( 'name' );
	if ( $paged >= 2 || $page >= 2 ) echo ' | ' . sprintf( __( 'Page %s', 'tisson' ), max( $paged, $page ) );
}
?>
</title>
<meta name="keywords" content="trusted technician, expert heating services, heat experts, heat technicians, local technicians, expert heat tune-up, furnace repair, local furnace repair, broken furnace, fix furnace, heating repair, annual furnace tune-ups">
<meta name="description" content="Annual heating tune-ups are critical to the performance of your HVAC system. Our technicians are familiar with every furnace make and model and are always comprehensive and thorough with every tune-up.">
<meta name="author" content="Servicechampions.com">
<link href="<?php echo get_template_directory_uri(); ?>/tission_css/style.css" rel="stylesheet">
<link href='https://fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,800,700,600,300" rel="stylesheet" type="text/css">
</head>
<body>

<style>
#post-12663 a.fixed-nav, #post-12663 > .section-post-header, #post-12663 .section.section-post-about, 
#post-14408 a.fixed-nav, #post-14408 > .section-post-header, #post-14408 .section.section-post-about, 
#post-14405 a.fixed-nav, #post-14405 > .section-post-header, #post-14405 .section.section-post-about, 
.mashsb-container {
	display: none;
}
</style>

<!-- MOBILE CONTACT FORM -->
<section id="mobile_contact_form">
   <div class="close-button">
   <div> <img alt="close_button" src="<?php echo get_template_directory_uri(); ?>/images/close_off_canvas_light.png"> <span>Close</span> </div>
  </div>
  <div id="include_mobile_contact_form" class="inner-padding-mobile">
		<?php echo do_shortcode('[gravityform id="52" name="Facebook Tune Up Tracking LP" title="false" description="false"]'); ?>
  </div>
</section>

<!-- DESKTOP -->
<section id="main_wrapper">
  <header>
    <div id="top_container">
      <div class="container">
        <div class="inner-padding"> 
          <!-- Company Info -->
          <div id="company_info"><img alt="company logo" src="<?php echo get_template_directory_uri(); ?>/images/logo.png"></div>
          <div id="number">
            <div  rel="trigger_mobile_nav"></div>
            <p id="top_number"><span class="call">CALL</span> <span id="number_rewrite"><a href="tel:714-907-1909">714-907-1909</a></span></p>
            <p class="sub-title">Local and Trusted Heating and Air Conditioning Experts</p>
          </div>
          <div class="clear"></div>
        </div>
      </div>
    </div>
    <!-- Slider -->
    <div class="slider">
      <div class="container">
        <div class="inner-padding">
          <div id="learn_more">
            <div class="learn-more-about-us">
              <h1>Professional Air Conditioning Tune-Up</h1>
            </div>
          </div>
          <div id="coupon_container">
            <div id='specials' style='background:url("http://dev.servicechampions.com/wp-content/uploads/2017/09/ac-tune-up-coupon.png") no-repeat scroll rgba(0, 0, 0, 0); background-size: 100%;'>
              <div id='print_coupon3'><span>PRINT</span></div>
              <p id='call'>Call this <b><?php echo date("l"); ?></b> for</p>
            </div>
                <!--div id="specials">
                    <div id="print_coupon"></div>
                </div--> 
                <!--img src="images/coupon.png"--> 
          </div>
          <div class="clear"></div>
        </div>
      </div>
    </div>
    <!-- SCHEDULE SERVICE -->
    <div id="schedule">
      <div class="container">
        <div class="inner-padding">
          <div id="contact_us_mobile" rel="trigger_mobile_contact"> <img src="<?php echo get_template_directory_uri(); ?>/images/email.png" id="email_logo" rel="trigger_mobile_contact">
            <p>CONTACT US</p>
            <div class="clear"></div>
          </div>
          <div id="sliding_marque">
            <div>
              <h4 id="h4_service">SCHEDULE SERVICE</h4>
              <p id="slide_in_number">714-907-1909</p>
            </div>
          </div>
          <div id="include_desktop_contact_form" class="form"> 
            <!-- Form -->
			<?php echo do_shortcode('[gravityform id="52" name="Facebook Tune Up Tracking LP" title="false" description="false"]'); ?>
            <div class="clear"></div>	
          </div>
        </div>
      </div>
    </div>
    <!-- THREE BOX -->
    <div id="three_box">
      <div class="container">
        <div class="three-box-article">
          <div class="three-box-one">
            <h4 class="three-box-h4">First-Rate Service</h4>
            <p class="three-box-p">We’re committed to excellency in every facet. We take a solutions-based approach and strive to achieve your complete satisfaction.</p>
          </div>
        </div>
        <div class="three-box-article">
          <div class="three-box-two">
            <h4 class="three-box-h4">Trusted Technicians</h4>
            <p class="three-box-p">Our technicians are background checked and drug tested. We never hire anyone we wouldn’t want working inside our own homes.</p>
          </div>
        </div>
        <div class="three-box-article">
          <div class="three-box-three">
            <h4 class="three-box-h4">Upfront Pricing</h4>
            <p class="three-box-p">We’ll provide you with the necessary information, upfront pricing and all options, so that you can make the best decision.</p>
          </div>
        </div>
        <div class="clear"></div>
      </div>
    </div>
  </header>
  <!-- SECTION ARTICLE -->
  <section id="section_content">
    <div class="container">
      <div class="inner-padding">
        <div id="copy" style="width:100%; float:none;">
			<?php 
				while ( have_posts() )
				{
					the_post();
					get_template_part( 'includes/content', 'single' );
				}
            ?>
        </div>
      </div>
    </div>
  </section>
  <!-- FOOTER -->
  <footer id="footer_content">
    <div class="container">
      <div class="inner-padding">
        <div class="contact-us">
          <p class="title">CALL <a href="tel:714-907-1909">714-907-1909</a></p>
          <p class="sub-title">Local and Trusted Heating and Air Conditioning Experts</p>
          <!-- BOTTOM NAV -->

        </div>
        <div id="copyright">
          <p>Copyright &copy; 2017 Service Champions Heating and Air Conditioning</p>
          <p>All Rights Reserved</p>
        </div>
        <div class="clear"></div>
      </div>
    </div> 
    </footer>
</section>
<script src="https://code.jquery.com/jquery-2.1.4.min.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/init.js" type="text/javascript"></script>    
<script type="text/javascript" data-cfasync="false">
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','__gaTracker');
	
	__gaTracker('create', 'UA-45418520-1', 'auto');
	__gaTracker('set', 'forceSSL', true);
	__gaTracker('require', 'displayfeatures');
	__gaTracker('require', 'linkid', 'linkid.js');
	__gaTracker('send','pageview');
</script> 
</body>
</html>
