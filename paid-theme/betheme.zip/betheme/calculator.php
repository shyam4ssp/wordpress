<?php
/**
 * Template Name: Calculator
 *
 * @package Tisson
 * @author Muffin Group
 */
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->

<!-- head -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Payment Calculator for Service Champions Heating &amp; Air Conditioning">
<meta name="theme-color" content="#005eae">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/x-icon" href="https://servicechampions.com/wp-content/service-champions-payment-calculator/images/favicon.ico?v=1">
<link rel="manifest" href="https://servicechampions.com/wp-content/service-champions-payment-calculator/manifest.json?v=1">
<link rel="stylesheet" type="text/css" href="https://servicechampions.com/wp-content/service-champions-payment-calculator/style.css?v=1">

<title>
<?php
global $post;
if( mfn_opts_get('mfn-seo') && is_object($post) && get_post_meta( get_the_ID(), 'mfn-meta-seo-title', true ) ){
	echo stripslashes( get_post_meta( get_the_ID(), 'mfn-meta-seo-title', true ) );
} else {
	global $page, $paged;
	wp_title( '|', true, 'right' );
	bloginfo( 'name' );
	if ( $paged >= 2 || $page >= 2 ) echo ' | ' . sprintf( __( 'Page %s', 'tisson' ), max( $paged, $page ) );
}
?>
</title>
</head>
<body>

<style>
#post-12663 a.fixed-nav, #post-12663 > .section-post-header, #post-12663 .section.section-post-about, 
#post-14408 a.fixed-nav, #post-14408 > .section-post-header, #post-14408 .section.section-post-about, 
#post-14405 a.fixed-nav, #post-14405 > .section-post-header, #post-14405 .section.section-post-about, 
.mashsb-container {
	display: none;
}
</style>



        <div class="outer-container">

            <div class="left-column">
                <img class="logo" src="https://servicechampions.com/wp-content/service-champions-payment-calculator/images/logo-400x172.png?v=1" alt="Service Champions">
                <h1>Payment Calculator</h1>
            </div>

            <div class="right-column">

                <img class="logo" src="https://servicechampions.com/wp-content/service-champions-payment-calculator/images/logo-400x172.png?v=1" alt="Service Champions">
                <h1>Payment Calculator</h1>
                <div class="hr"></div>

                <form>
                    <div class="form-line">
                        <label for="sale-amount">Sale Amount</label>
                        <div class="form-spacer"></div>
                        <div class="form-units">$</div>
                        <input type="number" class="number" id="sale-amount" name="sale-amount">
                    </div>
                    <div class="form-line">
                        <label for="incentive">Incentive</label>
                        <div class="form-spacer"></div>
                        <input type="number" class="number" id="incentive" name="incentive">
                        <select id="incentive-type" name="incentive-type">
                            <option value="$">$</option>
                            <option value="%">%</option>
                        </select>
                    </div>
                    <div class="form-line">
                        <label for="final-amount"><b>Final Amount</b></label>
                        <div class="form-spacer"></div>
                        <div class="form-units">$</div>
                        <input type="text" id="final-amount" name="final-amount" class="number readonly" value="0.00" readonly>
                    </div>
                </form>

                <div class="hr"></div>

                <div id="options-container">
                    <ul class="options">
                        <li id="payment-template" class="option">
                            <div class="description"></div>
                            <div class="payment-spacer"></div>
                            <div class="dollar-sign">$</div>
                            <div class="payment"></div>
                        </li>
                        <li class="custom option">
                            <div class="description">
                                <input id="custom-months" name="custom-months" type="number">
                                <label for="custom-months">Months</label>,
                                <input id="custom-interest" name="custom-interest" type="number">
                                <label for="custom-interest">% Interest</label>
                            </div>
                            <div class="payment-spacer"></div>
                            <div class="dollar-sign hidden">$</div>
                            <div class="payment hidden">0.00</div>
                        </li>
                    </ul>
                </div>

            </div>

        </div>

        <script src="https://servicechampions.com/wp-content/service-champions-payment-calculator/jquery/jquery-3.3.1.min.js"></script>
        <script src="https://servicechampions.com/wp-content/service-champions-payment-calculator/calculator.js?v=2"></script>

        <script>
            if ('serviceWorker' in navigator) {
                $(function () {
                    navigator.serviceWorker.register('service-worker.js');
                });
            }
        </script>

    </body>
</html>
