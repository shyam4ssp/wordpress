<?php
/**
 * Email Addresses
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/email-addresses.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates/Emails
 * @version     3.2.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$text_align = is_rtl() ? 'right' : 'left';

?>

<table id="addresses" cellspacing="0" cellpadding="0" style="width: 100%; vertical-align: top; margin-bottom: 40px; padding:0;" border="0">
  <tr>
    <td style="text-align:<?php echo $text_align; ?>; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; border:0; padding:0;" valign="top"><h2>
        <?php _e( 'Customer details', 'woocommerce' ); ?>
      </h2>
      <address class="address">
      <?php if ( $order->get_billing_email() ): ?>
      <p><strong>Email:</strong> <?php echo esc_html( $order->get_billing_email() ); ?></p>
      <?php endif; ?>
      </address></td>
  </tr>
  <tr>
    <td style="text-align:<?php echo $text_align; ?>; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; border:0; padding:0;" valign="top"><h3>
        <?php _e( 'Information', 'woocommerce' ); ?>
      </h3>
      <address class="address">
      <?php echo ( $address = $order->get_formatted_billing_address() ) ? $address : __( 'N/A', 'woocommerce' ); ?>
      </address></td>
      </td>
  </tr>
</table>
<h3>If paying by check, please make checks payable to Service Champions.<br />
If paying by credit card, the following is required:</h3>
<p style="font-size:13px;">Credit Card Number:______________________________<br />
  Expiration Date: _______________/__________________<br />
  Billing Zipcode:___________________________________<br />
  Billing City:_______________________________________<br />
  <b>1.</b> Please print the invoice order that has been sent to the email address you provided.<br />
  <b>2.</b> Seal it in the Service Champions Store envelope, and turn it into the Secure Payment Bin.<br />
  <b>3.</b> Payment must be made prior to the order being fulfilled.<br />
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>a.</b> Once the payment has been received and processed, we will confirm via email.<br />
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>b.</b> Once the order has been placed, the transaction is final.<br />
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>i.</b> As this is a custom order, there are no returns or exchanges.<br />
  <b>4.</b> Estimated delivery for products and clothing is a minimum of 2-3 weeks after monthly order.</p>
