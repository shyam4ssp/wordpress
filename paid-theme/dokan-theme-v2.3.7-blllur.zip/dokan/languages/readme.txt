Instructions:
----------------------------
1. File name structure is: LOCALE.po, e.g: en_US.po
2. Copy dokan.pot in you language, and open with poEdit
3. Translate

Place your theme language files in this directory.

Please visit the following links to learn more about translating WordPress themes:

http://codex.wordpress.org/Translating_WordPress
