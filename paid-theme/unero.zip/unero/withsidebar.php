<?php
/**
 * Template Name: Left Sidebar With Product
 *
 * The template file for displaying home page.
 *
 * @package Unero
 */

get_header(); ?>

<aside id="primary-sidebar" class="widgets-area primary-sidebar col-md-3 col-sm-12 col-xs-12 catalog-sidebar">
    <?php dynamic_sidebar( 'page-sidebar' ); ?>
</aside>
<?php
if ( have_posts() ) :
	while ( have_posts() ) : the_post();
		the_content();
	endwhile;

endif;
?>
<?php get_footer(); ?>
