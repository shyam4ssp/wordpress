<?php 

add_action( 'wp_enqueue_scripts', 'visapro_enqueue_styles' );
function visapro_enqueue_styles() {
    wp_enqueue_style( 'visapro-parent-style', get_template_directory_uri() . '/style.css' );

}