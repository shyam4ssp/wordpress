=== visapro===
Theme Name: visapro 
Theme URI:http://raytheme.com
Description: visapro Responsive WordPress Theme
Author: themex
Author URI: https://webitrangpur.com/
Version: 1.0.0
Tags: slider.
Text Domain: visapro
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==
visapro Responsive WordPress Theme

For more information about visapro please go to webitrangpur.com

== Installation ==

Please see installation guide in Documentation. here https://webitrangpur.com/