<?php
class BDWP_PluginInfo {

    public static function GetVersion() {
    	return '4.2.4';
    }

    public static function License() {
    	return __('Free', 'botdetect-wp-captcha'); // Free, GPL, Paid
    }
}
