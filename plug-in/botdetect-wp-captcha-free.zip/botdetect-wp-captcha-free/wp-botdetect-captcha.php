<?php
/*
Plugin Name: BotDetect CAPTCHA
Plugin URI: https://captcha.com/doc/php/wordpress-captcha.html?utm_source=plugin&amp;utm_medium=wp&amp;utm_campaign=4.2.3
Description: Adds BotDetect CAPTCHA to WordPress comments, login, registration, lost password, and Contact Form 7.
Version: 4.2.3
Author: BotDetect CAPTCHA
Author URI: https://captcha.com?utm_source=plugin&amp;utm_medium=wp&amp;utm_campaign=4.2.3
*/
include_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'wp-botdetect-captcha.php');
