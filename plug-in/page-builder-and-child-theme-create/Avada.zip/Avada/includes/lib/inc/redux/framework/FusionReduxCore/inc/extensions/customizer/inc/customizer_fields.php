<?php

	class FusionRedux_Customizer_Control_checkbox extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-checkbox";
	}
	class FusionRedux_Customizer_Control_color_rgba extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-color_rgba";
	}
	class FusionRedux_Customizer_Control_color extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-color";
	}
	//class FusionRedux_Customizer_Control_raw extends FusionRedux_Customizer_Control {
	//    public $type = "fusionredux-raw";
	//}
	class FusionRedux_Customizer_Control_media extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-media";
	}
	class FusionRedux_Customizer_Control_spinner extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-spinner";
	}
	class FusionRedux_Customizer_Control_palette extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-palette";
	}
	class FusionRedux_Customizer_Control_button_set extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-button_set";
	}
	class FusionRedux_Customizer_Control_image_select extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-image_select";
	}
	class FusionRedux_Customizer_Control_radio extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-radio";
	}
	class FusionRedux_Customizer_Control_select extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-select";
	}
	class FusionRedux_Customizer_Control_gallery extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-gallery";
	}
	class FusionRedux_Customizer_Control_slider extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-slider";
	}
	class FusionRedux_Customizer_Control_sortable extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-sortable";
	}
	class FusionRedux_Customizer_Control_switch extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-switch";
	}
	class FusionRedux_Customizer_Control_text extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-text";
	}
	class FusionRedux_Customizer_Control_textarea extends FusionRedux_Customizer_Control {
		public $type = "fusionredux-textarea";
	}
