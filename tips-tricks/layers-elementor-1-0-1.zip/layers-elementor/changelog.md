# Layers Changelog

##1.0.0
### 13 November 2018

* **Integration** - Layers becomes Layers by Elementor