export interface IResponseGenerator {
  config?: object;
  data?: any;
  headers?: any;
  request?: object;
  status?: number;
  statusText?: string;
}
