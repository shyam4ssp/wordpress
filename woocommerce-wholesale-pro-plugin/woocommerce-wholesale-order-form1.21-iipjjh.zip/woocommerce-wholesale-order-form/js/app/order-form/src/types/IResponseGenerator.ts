export interface IResponseGenerator {
  config?: object;
  data?: any;
  headers?: object;
  request?: object;
  status?: number;
  statusText?: string;
}
