// ORDER FORM
export enum EOrderFormI18nActionTypes {
  FETCH_STRINGS = "FETCH_STRINGS",
  SET_STRINGS = "SET_STRINGS",
}

export interface II18n {
  frontend: string[];
}
